export type Attack = {
  id: string;
  target: string;
  port: number;
  duration: number;
  method: string;
  startTime: number;
  status: 'Ongoing' | 'Success' | 'Failure';
};

export type Server = {
  id: string;
  url: string;
  status: 'Untested' | 'Online' | 'Offline' | 'Testing';
};

export type MusicPlayerState = {
  isVisible: boolean;
  isPlaying: boolean;
  isExpanded: boolean;
  isMinimized: boolean;
  track: {
    title: string;
    artist: string;
    albumArt: string;
    audioSrc: string;
  } | null;
};
