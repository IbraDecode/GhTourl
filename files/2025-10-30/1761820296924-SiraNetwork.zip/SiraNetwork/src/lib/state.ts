"use client";

import { useState, useEffect } from 'react';
import type { Attack, Server, MusicPlayerState } from "@/lib/types";

// This is a global state management solution to share state between pages.

type DashboardStateData = {
    attacks: Attack[];
    servers: Server[];
    musicPlayer: MusicPlayerState;
};

const initialState: DashboardStateData = {
    attacks: [], // Will be populated by API
    servers: [], // Will be populated by API/local storage
    musicPlayer: {
      isVisible: false,
      isPlaying: false,
      isExpanded: false,
      isMinimized: false, 
      track: null,
    },
};

let state: DashboardStateData = { ...initialState };

const listeners = new Set<() => void>();

const subscribe = (listener: () => void) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
};

const setState = (updater: (prevState: DashboardStateData) => DashboardStateData, silent: boolean = false) => {
    state = updater(state);
    if (!silent) {
      listeners.forEach(l => l());
    }
};

const useSharedState = () => {
    const [localState, setLocalState] = useState(state);

    useEffect(() => {
        // Load servers from local storage on mount
        try {
            const storedServers = localStorage.getItem("siranetwork_servers");
            if (storedServers) {
                const servers = JSON.parse(storedServers);
                 setState(prev => ({...prev, servers}), true);
                 setLocalState(prev => ({...prev, servers}));
            }
        } catch (e) {
            console.error("Failed to load servers from local storage", e);
        }

        const unsubscribe = subscribe(() => setLocalState(state));
        return () => unsubscribe();
    }, []);

    return {
        attacks: localState.attacks,
        servers: localState.servers,
        musicPlayer: localState.musicPlayer,
        setAttacks: (updater: (prev: Attack[]) => Attack[]) => {
            setState(prevState => ({ ...prevState, attacks: updater(prevState.attacks) }));
        },
        setServers: (updater: (prev: Server[]) => Server[]) => {
            const newState = updater(state.servers);
            try {
                localStorage.setItem("siranetwork_servers", JSON.stringify(newState));
            } catch(e) {
                console.error("Failed to save servers to local storage", e);
            }
            setState(prevState => ({ ...prevState, servers: newState }));
        },
        setMusicPlayer: (updater: (prev: MusicPlayerState) => MusicPlayerState) => {
            setState(prevState => ({ ...prevState, musicPlayer: updater(prevState.musicPlayer) }));
        },
    };
};

const getServersState = (): Promise<Server[]> => {
    return new Promise(resolve => {
        // This is a bit of a hack to access the current state outside of a component.
        // It resolves immediately with the current server state.
        resolve(state.servers);
    });
};


export const DashboardState = {
    useState: useSharedState,
    getServersState,
};
