"use client";

import { ServerManagement } from "@/app/components/server-management";
import type { Server, MusicPlayerState } from "@/lib/types";
import { DashboardState } from "@/lib/state";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Music } from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";


export default function ServerPage() {
  const { servers, setServers, setMusicPlayer } = DashboardState.useState();
  const { toast } = useToast();

  const handleAddServer = (url: string) => {
    // Basic URL validation
    try {
      new URL(url);
    } catch (error) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid server URL (e.g., http://localhost:3001).",
        variant: "destructive",
      });
      return;
    }

    if (servers.some(s => s.url === url)) {
        toast({
            title: "Server Exists",
            description: "This server URL has already been added.",
            variant: "destructive",
        });
        return;
    }

    const newServer: Server = {
      id: crypto.randomUUID(),
      url,
      status: "Untested",
    };
    setServers((prev) => [...prev, newServer]);
  };

  const handleDeleteServer = (id: string) => {
    setServers((prev) => prev.filter((s) => s.id !== id));
  };

  const testServer = async (server: Server) => {
    setServers(prev => prev.map(s => s.id === server.id ? {...s, status: 'Testing'} : s));
    
    try {
        const response = await fetch(server.url + '/stats', {
            signal: AbortSignal.timeout(5000) // 5 second timeout
        });
        if (response.ok) {
            const data = await response.json();
            if (data.status === 'online') {
                setServers(prev => prev.map(s => s.id === server.id ? {...s, status: 'Online'} : s));
            } else {
                 throw new Error("Invalid response status");
            }
        } else {
            throw new Error(`Server responded with status ${response.status}`);
        }
    } catch (error) {
        console.error(`Failed to test server ${server.url}:`, error);
        setServers(prev => prev.map(s => s.id === server.id ? {...s, status: 'Offline'} : s));
    }
  };
  
  const handleTestServers = () => {
    if (servers.length === 0) {
        toast({
            title: "No Servers",
            description: "Add a server before testing.",
        });
        return;
    }
    servers.forEach(testServer);
  };
  
  const handlePlayMusic = () => {
    setMusicPlayer((prev: MusicPlayerState) => {
      // If a track is already set, just toggle play/pause
      if (prev.track) {
        return { ...prev, isPlaying: !prev.isPlaying, isVisible: true, isMinimized: false };
      }
      // Otherwise, start the new track
      return {
        ...prev,
        isPlaying: true,
        isVisible: true,
        isExpanded: false,
        isMinimized: false,
        track: {
          title: "An Angels Love ( BreakBeat Remix )",
          artist: "Sira",
          albumArt: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761739220774-photo.jpg",
          audioSrc: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761734096472-2_5193122331429471538.mp3",
        },
      };
    });
  };

  return (
    <div className="flex-1 space-y-6 p-4 md:p-6">
      <div className="relative flex flex-col items-center justify-center text-center p-8 md:p-12 rounded-xl bg-card shadow-sm overflow-hidden min-h-[200px]">
        <Image
          src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253514-photo.jpg"
          alt="Server Management Hero Image"
          fill
          className="object-cover opacity-20"
          data-ai-hint="server circuit"
        />
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground font-headline">
            API Server Management
          </h1>
          <p className="mt-2 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Add, remove, and test your 4pi API endpoints.
          </p>
        </div>
         <Button onClick={handlePlayMusic} variant="link" className="mt-4 z-10 text-muted-foreground hover:text-primary">
          <Music className="mr-2 h-4 w-4" />
          sebelum ddos dengerin musik asik bro
        </Button>
        <p className="z-10 text-xs text-muted-foreground/80 mt-2">Built By <Link href="https://t.me/ibradecode" target="_blank" className="underline hover:text-primary">IbraDecode</Link></p>
      </div>
      
      <ServerManagement 
        servers={servers}
        onAddServer={handleAddServer}
        onDeleteServer={handleDeleteServer}
        onTestServers={handleTestServers}
      />
    </div>
  );
}
