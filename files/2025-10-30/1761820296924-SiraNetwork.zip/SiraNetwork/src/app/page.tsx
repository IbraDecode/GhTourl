"use client";

import * as React from 'react';
import { OngoingAttacks } from "@/app/components/ongoing-attacks";
import type { MusicPlayerState } from "@/lib/types";
import Image from "next/image";
import { DashboardState } from "@/lib/state";
import { AttackStats } from "./components/attack-stats";
import { Button } from "@/components/ui/button";
import { Music } from "lucide-react";
import Link from "next/link";
import { AttackHistoryTable } from "./components/attack-history-table";

export default function DashboardPage() {
  const { attacks, setMusicPlayer } = DashboardState.useState();

  const handlePlayMusic = () => {
    setMusicPlayer((prev: MusicPlayerState) => {
      if (prev.track) {
        return { ...prev, isPlaying: !prev.isPlaying, isVisible: true, isMinimized: false };
      }
      return {
        ...prev,
        isPlaying: true,
        isVisible: true,
        isExpanded: false,
        isMinimized: false,
        track: {
          title: "An Angels Love ( BreakBeat Remix )",
          artist: "Sira",
          albumArt: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761739220774-photo.jpg",
          audioSrc: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761734096472-2_5193122331429471538.mp3",
        },
      };
    });
  };

  const ongoingAttacks = attacks.filter(a => a.status === 'Ongoing');

  return (
    <div className="flex-1 space-y-6 p-4 md:p-6">
       <div className="relative flex flex-col items-center justify-center text-center p-8 md:p-12 rounded-xl bg-card shadow-sm overflow-hidden min-h-[200px]">
        <Image
          src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806282095-photo.jpg"
          alt="SiraNetwork Hero Image"
          fill
          className="object-cover opacity-20"
          data-ai-hint="hacker technology"
        />
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground font-headline">
            Welcome to SiraNetwork
          </h1>
          <p className="mt-2 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Advanced automation tool for professional network security.
          </p>
        </div>
         <Button onClick={handlePlayMusic} variant="link" className="mt-4 z-10 text-muted-foreground hover:text-primary">
          <Music className="mr-2 h-4 w-4" />
          sebelum ddos dengerin musik asik bro
        </Button>
        <p className="z-10 text-xs text-muted-foreground/80 mt-2">Built By <Link href="https://t.me/ibradecode" target="_blank" className="underline hover:text-primary">IbraDecode</Link></p>
      </div>
      
      <AttackStats attacks={attacks} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="lg:col-span-2">
          <OngoingAttacks attacks={ongoingAttacks} />
        </div>
        <div className="lg:col-span-2">
            <AttackHistoryTable attacks={attacks} />
        </div>
      </div>
    </div>
  );
}
