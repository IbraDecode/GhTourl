"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Attack } from "@/lib/types"
import { Activity, CheckCircle, XCircle } from "lucide-react"
import Image from "next/image";

interface AttackStatsProps {
  attacks: Attack[];
}

export function AttackStats({ attacks }: AttackStatsProps) {
  const activeAttacks = attacks.filter(a => a.status === 'Ongoing').length;
  const successfulAttacks = attacks.filter(a => a.status === 'Success').length;
  const failedAttacks = attacks.filter(a => a.status === 'Failure').length;

  return (
    <div className="grid gap-6 md:grid-cols-3">
        <Card className="relative overflow-hidden">
            <Image
              src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253077-photo.jpg"
              alt="Active Attacks Background"
              fill
              className="object-cover opacity-10"
              data-ai-hint="digital binary code"
            />
            <div className="relative">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Active Attacks</CardTitle>
                    <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{activeAttacks}</div>
                    <p className="text-xs text-muted-foreground">Currently running attacks</p>
                </CardContent>
            </div>
        </Card>
        <Card className="relative overflow-hidden">
             <Image
              src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253514-photo.jpg"
              alt="Successful Attacks Background"
              fill
              className="object-cover opacity-10"
              data-ai-hint="network success"
            />
            <div className="relative">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Successful Attacks</CardTitle>
                    <CheckCircle className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{successfulAttacks}</div>
                    <p className="text-xs text-muted-foreground">Total successful attacks</p>
                </CardContent>
            </div>
        </Card>
        <Card className="relative overflow-hidden">
             <Image
              src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806277479-sticker.webp"
              alt="Failed Attacks Background"
              fill
              className="object-contain object-right opacity-5"
              data-ai-hint="error danger"
            />
            <div className="relative">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Failed Attacks</CardTitle>
                    <XCircle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{failedAttacks}</div>
                    <p className="text-xs text-muted-foreground">Total failed attacks</p>
                </CardContent>
            </div>
        </Card>
    </div>
  )
}
