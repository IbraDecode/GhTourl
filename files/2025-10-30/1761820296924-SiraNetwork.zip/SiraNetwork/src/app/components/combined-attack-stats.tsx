"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Attack } from "@/lib/types"
import { Activity, CheckCircle, XCircle } from "lucide-react"
import Image from "next/image";
import { Separator } from "@/components/ui/separator";

interface CombinedAttackStatsProps {
  attacks: Attack[];
}

export function CombinedAttackStats({ attacks }: CombinedAttackStatsProps) {
  const activeAttacks = attacks.filter(a => a.status === 'Ongoing').length;
  const successfulAttacks = attacks.filter(a => a.status === 'Success').length;
  const failedAttacks = attacks.filter(a => a.status === 'Failure').length;

  const stats = [
    {
      title: "Active",
      value: activeAttacks,
      icon: <Activity className="h-4 w-4 text-primary" />,
      description: "Ongoing",
    },
    {
      title: "Success",
      value: successfulAttacks,
      icon: <CheckCircle className="h-4 w-4 text-green-500" />,
      description: "Completed",
    },
    {
      title: "Failed",
      value: failedAttacks,
      icon: <XCircle className="h-4 w-4 text-red-500" />,
      description: "Terminated",
    },
  ];

  return (
    <Card className="relative overflow-hidden">
        <Image
          src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253077-photo.jpg"
          alt="Attack Stats Background"
          fill
          className="object-cover opacity-10"
          data-ai-hint="digital data stream"
        />
        <div className="relative">
            <CardHeader className="pb-4">
                <CardTitle className="text-lg">Attack Summary</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex justify-around items-center text-center">
                    {stats.map((stat, index) => (
                        <React.Fragment key={stat.title}>
                            <div className="flex flex-col items-center gap-1 w-24">
                                <div className="flex items-center justify-center gap-2">
                                  {stat.icon}
                                  <span className="text-2xl font-bold">{stat.value}</span>
                                </div>
                                <p className="text-xs text-muted-foreground">{stat.title}</p>
                            </div>
                            {index < stats.length - 1 && (
                                <Separator orientation="vertical" className="h-10" />
                            )}
                        </React.Fragment>
                    ))}
                </div>
            </CardContent>
        </div>
    </Card>
  )
}
