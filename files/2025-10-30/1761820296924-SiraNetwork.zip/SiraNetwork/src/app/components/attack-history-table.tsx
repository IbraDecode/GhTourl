"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Activity,
  CheckCircle,
  XCircle,
  ShieldQuestion,
  ListFilter,
  Target,
  Clock,
  ServerCrash,
  Zap,
} from "lucide-react";
import type { Attack } from "@/lib/types";
import Image from "next/image";
import { cn, formatTime } from "@/lib/utils";

interface AttackHistoryTableProps {
  attacks: Attack[];
}

const statusConfig = {
  Ongoing: {
    icon: <Activity className="h-4 w-4 text-primary" />,
    variant: "secondary",
    label: "Ongoing",
  },
  Success: {
    icon: <CheckCircle className="h-4 w-4 text-green-500" />,
    variant: "default",
    label: "Success",
  },
  Failure: {
    icon: <XCircle className="h-4 w-4 text-red-500" />,
    variant: "destructive",
    label: "Failure",
  },
};

export function AttackHistoryTable({ attacks }: AttackHistoryTableProps) {
  const sortedAttacks = [...attacks].sort((a, b) => b.startTime - a.startTime);

  return (
    <Card className="relative overflow-hidden">
      <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810454405-photo.jpg"
        alt="Attack History Background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="digital data stream"
      />
      <div className="relative">
        <CardHeader>
          <CardTitle>Attack History</CardTitle>
          <CardDescription>
            A log of all initiated attacks.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[120px]">Status</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead className="hidden md:table-cell">Method</TableHead>
                  <TableHead className="hidden sm:table-cell text-right">Duration</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedAttacks.length > 0 ? (
                  sortedAttacks.map((attack) => (
                    <TableRow key={attack.id}>
                      <TableCell>
                        <Badge variant={statusConfig[attack.status]?.variant || "secondary"} className="gap-1.5">
                          {statusConfig[attack.status]?.icon || <ShieldQuestion className="h-4 w-4" />}
                          {statusConfig[attack.status]?.label || "Unknown"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 font-medium">
                           <Zap className="h-4 w-4 text-muted-foreground"/>
                           <span>{attack.target}:{attack.port}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{attack.method}</TableCell>
                      <TableCell className="hidden sm:table-cell text-right font-mono">{formatTime(attack.duration)}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      No attacks have been run yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </div>
    </Card>
  );
}
