"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Target,
  Zap,
} from "lucide-react";
import type { Attack } from "@/lib/types";
import { formatTime } from "@/lib/utils";
import Image from "next/image";

interface OngoingAttacksProps {
  attacks: Attack[];
}

function AttackItem({
  attack,
}: {
  attack: Attack;
}) {
  const [timeRemaining, setTimeRemaining] = useState(attack.duration - (Date.now() - attack.startTime) / 1000);
  const progress = ((attack.duration - timeRemaining) / attack.duration) * 100;

  useEffect(() => {
    if (timeRemaining <= 0) {
      return;
    }

    const timer = setInterval(() => {
       const elapsed = (Date.now() - attack.startTime) / 1000;
       setTimeRemaining(Math.max(0, attack.duration - elapsed));
    }, 1000);

    return () => clearInterval(timer);
  }, [attack.startTime, attack.duration, timeRemaining]);

  return (
    <div className="flex flex-col gap-4 rounded-lg border bg-card/50 backdrop-blur-sm p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="grid gap-2 sm:flex-1">
        <div className="flex items-center gap-2 font-medium">
          <Zap className="h-4 w-4 text-primary"/>
          <span>{attack.method} Attack</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            <span>{attack.target}:{attack.port}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 sm:w-1/3">
        <div className="flex-1 space-y-1">
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-muted-foreground text-right font-mono">
            {formatTime(Math.ceil(timeRemaining))}
          </p>
        </div>
      </div>
    </div>
  );
}

export function OngoingAttacks({ attacks }: OngoingAttacksProps) {
  return (
    <Card className="relative overflow-hidden">
       <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810438881-photo.jpg"
        alt="Ongoing attacks background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="digital matrix"
      />
      <div className="relative">
        <CardHeader>
          <CardTitle>Ongoing Attacks</CardTitle>
          <CardDescription>
            Real-time status of all active attacks.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {attacks.length > 0 ? (
            <div className="space-y-4">
              {attacks.map((attack) => (
                <AttackItem
                  key={`${attack.id}-${attack.startTime}`}
                  attack={attack}
                />
              ))}
            </div>
          ) : (
            <div className="flex h-24 items-center justify-center rounded-md border border-dashed bg-card/50 backdrop-blur-sm">
              <p className="text-sm text-muted-foreground">No active attacks.</p>
            </div>
          )}
        </CardContent>
      </div>
    </Card>
  );
}
