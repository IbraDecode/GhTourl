"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Zap, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/attack", icon: Zap, label: "Attack" },
    { href: "/server", icon: Server, label: "Server" },
];

export function BottomNavbar() {
    const pathname = usePathname();

    return (
        <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-sm border-t p-2 z-50">
            <div className="grid grid-cols-3 justify-around items-center max-w-2xl mx-auto relative">
                {navItems.map((item) => (
                    <Button
                        key={item.label}
                        asChild
                        variant="ghost" 
                        className={cn(
                            "flex flex-col h-auto items-center gap-1 p-2 text-muted-foreground hover:text-primary",
                            pathname === item.href && "text-primary"
                        )}
                    >
                        <Link href={item.href}>
                            <item.icon className="h-5 w-5" />
                            <span className="text-xs">{item.label}</span>
                        </Link>
                    </Button>
                ))}
            </div>
        </div>
    );
}
