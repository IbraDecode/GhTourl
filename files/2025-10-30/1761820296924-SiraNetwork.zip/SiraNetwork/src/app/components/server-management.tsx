"use client";

import { useState } from "react";
import { Plus, Trash2, Network, Loader, CircleDot, Circle, XCircle } from "lucide-react";
import Image from "next/image";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import type { Server } from "@/lib/types";
import { cn } from "@/lib/utils";

interface ServerManagementProps {
  servers: Server[];
  onAddServer: (url: string) => void;
  onDeleteServer: (id: string) => void;
  onTestServers: () => void;
}

const statusIcons = {
  Untested: <Circle className="h-3 w-3 text-muted-foreground" />,
  Online: <CircleDot className="h-3 w-3 text-green-500" />,
  Offline: <XCircle className="h-3 w-3 text-red-500" />,
  Testing: <Loader className="h-3 w-3 animate-spin" />,
};

const statusColors: { [key in Server['status']]: "default" | "secondary" | "destructive" | "outline"} = {
  Untested: "secondary",
  Online: "default",
  Offline: "destructive",
  Testing: "outline",
}

export function ServerManagement({
  servers,
  onAddServer,
  onDeleteServer,
  onTestServers,
}: ServerManagementProps) {
  const [newServerUrl, setNewServerUrl] = useState("");

  const handleAddClick = () => {
    if (newServerUrl.trim()) {
      onAddServer(newServerUrl.trim());
      setNewServerUrl("");
    }
  };
  
  return (
    <Card className="relative overflow-hidden">
        <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253514-photo.jpg"
        alt="Server management background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="server circuit"
      />
      <div className="relative z-10">
        <CardHeader>
          <CardTitle>4pi Server List</CardTitle>
          <CardDescription>Manage your API endpoints for 4pi attacks.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex gap-2">
            <Input
              value={newServerUrl}
              onChange={(e) => setNewServerUrl(e.target.value)}
              placeholder="https://your-api-endpoint.com"
              className="bg-background/80"
            />
            <Button onClick={handleAddClick} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="h-64 rounded-md border bg-card/50 backdrop-blur-sm p-2">
             <ScrollArea className="h-full w-full">
               {servers.length > 0 ? (
                 <div className="space-y-2">
                   {servers.map((server) => (
                     <div key={server.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50">
                       <div className="flex items-center gap-2 flex-grow min-w-0">
                         {statusIcons[server.status]}
                         <span className="truncate text-sm">{server.url}</span>
                       </div>
                       <Badge variant={statusColors[server.status]} className="hidden sm:inline-flex">{server.status}</Badge>
                       <Button
                         variant="ghost"
                         size="icon"
                         className="h-8 w-8 shrink-0"
                         onClick={() => onDeleteServer(server.id)}
                       >
                         <Trash2 className="h-4 w-4" />
                       </Button>
                     </div>
                   ))}
                 </div>
               ) : (
                 <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                   No servers added yet.
                 </div>
               )}
             </ScrollArea>
           </div>
        </CardContent>
        <CardFooter>
          <Button onClick={onTestServers} className="w-full" variant="outline">
            <Network /> Test All Servers
          </Button>
        </CardFooter>
      </div>
    </Card>
  );
}
