"use client";

import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { BottomNavbar } from './components/bottom-navbar';
import Image from 'next/image';
import { DynamicIsland } from './components/dynamic-island';
import * as React from 'react';
import { DashboardState } from '@/lib/state';
import type { Attack } from '@/lib/types';


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const { setAttacks } = DashboardState.useState();

  React.useEffect(() => {
    const fetchStats = () => {
      // Use the getter function to get the latest state
      // without needing to include `servers` in the dependency array.
      DashboardState.getServersState().then(currentServers => {
        const onlineServers = currentServers.filter(s => s.status === 'Online');
        if (onlineServers.length === 0) {
          setAttacks(() => []); // Clear attacks if no servers are online
          return;
        }

        const promises = onlineServers.map(server =>
          fetch(server.url + '/stats')
            .then(res => res.ok ? res.json() : Promise.reject(`Server ${server.url} failed`))
            .then(data => data.history || [])
            .catch(err => {
              // console.error(`Failed to fetch stats from ${server.url}:`, err);
              return [];
            })
        );
        
        Promise.all(promises).then(results => {
          const combinedHistory = results.flat();
    
          // Deduplicate attacks based on a composite key
          const uniqueAttacks = Array.from(new Map(combinedHistory.map((attack: Attack) => {
            // A more robust key
            const key = `${attack.target}-${attack.port}-${attack.method}-${attack.startTime}`;
            return [key, attack];
          })).values());
    
          setAttacks(() => (uniqueAttacks as Attack[]).sort((a, b) => b.startTime - a.startTime));
        });
      });
    };

    const intervalId = setInterval(fetchStats, 3000);
    fetchStats(); // Initial fetch

    return () => clearInterval(intervalId);
  }, [setAttacks]); // setAttacks from useState is stable and won't cause re-renders.

  return (
    <html lang="en" className="dark">
      <head>
        <title>SiraNetwork</title>
        <meta name="description" content="Advanced automation tool" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased">
          <div className="relative flex flex-col min-h-screen">
            <DynamicIsland />
            <div className="absolute bottom-0 left-0 right-0 z-0 h-96 w-full opacity-10">
              <Image
                src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761808764360-sticker.webp"
                alt="Background Wave"
                fill
                className="object-cover"
              />
            </div>
            <main className="flex-1 pb-24 z-10">{children}</main>
            <BottomNavbar />
          </div>
          <Toaster />
      </body>
    </html>
  );
}
