# **App Name**: SiraXDDoS Web

## Core Features:

- Attack: Initiate a DDoS attack on a target with specified methods and duration.
- Add 4pi Server: Add a new 4pi server endpoint to the list of available servers.
- Delete 4pi Server: Remove a 4pi server endpoint from the list.
- List 4pi Servers: Display all currently configured 4pi server endpoints.
- Test 4pi Servers: Test the connectivity of all configured 4pi servers.
- Start Attack with 4pi: Initiate a DDoS attack using the 4pi servers with specified target, time, and methods.
- Ongoing Attack Monitor: Monitor the status of ongoing attacks, displaying target, duration, and method used.

## Style Guidelines:

- Primary color: Deep violet (#734DBC), symbolizing power and technological sophistication.
- Background color: Light gray (#000000). It provides a clean, modern canvas for content.
- Accent color: Electric purple (#C273EB). Highlights important interactive elements.
- Headline font: 'Space Grotesk' (sans-serif), offering a tech-centric, modern aesthetic for titles and headings.
- Body font: 'Inter' (sans-serif), providing a clean and readable style for descriptions and interface elements.
- Use a set of simple, line-based icons that represent actions like 'attack,' 'add,' 'delete,' and 'monitor'. The style should be consistent and minimalist to align with the overall modern aesthetic.
- Maintain a clean and organized layout. Use grid-based design principles to arrange elements logically. Ensure adequate spacing and clear visual hierarchy to make the interface intuitive.