
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/shared/logo";
import { WavyShape } from "@/components/shared/wavy-shape";
import Image from "next/image";
import Link from "next/link";
import BackgroundCanvas from "@/components/shared/background-canvas";
import { FirebaseClientProvider } from "@/firebase/client-provider";
import { useUser, useAuth, useFirestore, initiateAnonymousSignIn } from "@/firebase";
import { SubmitButton } from "@/components/shared/submit-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { collection, query, where, getDocs } from "firebase/firestore";

function LoginPageContent() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const firestore = useFirestore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    // If auth state is resolved and there's a user, redirect.
    if (!isUserLoading && user) {
      router.push("/dashboard");
    }
    // If auth state is resolved and there's NO user, show the login form.
    if (!isUserLoading && !user) {
      setShowLogin(true);
    }
  }, [user, isUserLoading, router]);

  const handleAnonymousLogin = async () => {
    if (!auth) return;
    setIsSubmitting(true);
    try {
        await initiateAnonymousSignIn(auth);
        // Let the useEffect handle the redirect
    } catch(e) {
        toast({ variant: "destructive", title: "Error", description: "Anonymous login failed." });
        setIsSubmitting(false);
    }
  };
  
  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const formData = new FormData(e.currentTarget);
    const username = formData.get("username") as string;
    const accessKey = formData.get("accessKey") as string;

    if (!firestore || !auth) {
      toast({ variant: "destructive", title: "Error", description: "System not ready." });
      setIsSubmitting(false);
      return;
    }

    try {
      const keysRef = collection(firestore, 'api_keys');
      const q = query(keysRef, where("key", "==", accessKey), where("username", "==", username));
      
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        toast({
          variant: "destructive",
          title: "Login Failed",
          description: "Invalid username or access key.",
        });
        setIsSubmitting(false);
        return;
      }
      
      const apiKeyDoc = querySnapshot.docs[0].data();

      await initiateAnonymousSignIn(auth, apiKeyDoc.userId, {
        username: apiKeyDoc.username,
        role: apiKeyDoc.role || 'premium',
      });
      // Let the useEffect handle the redirect
      
    } catch (error) {
      console.error("Login error:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred during login.",
      });
      setIsSubmitting(false);
    }
  }

  // Loading state
  if (!showLogin) {
    return (
        <div className="flex min-h-screen items-center justify-center p-4 bg-background">
            <Image 
              src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761729760869-photo.jpg"
              alt="Loading..."
              width={100}
              height={100}
              className="rounded-full animate-pulse"
              priority
            />
        </div>
    )
  }

  // Login form
  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-background">
      <BackgroundCanvas />
      <div className="w-full max-w-sm relative z-10 animate-fade-in-up">
        <div className="bg-card rounded-3xl shadow-2xl overflow-hidden">
          <div className="relative h-64">
            <WavyShape className="w-[calc(100%+2px)] -ml-px" />
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-primary-foreground text-center">
              <h1 className="text-3xl font-bold tracking-tight">Halo Puki,</h1>
              <h2 className="text-4xl font-extrabold tracking-tighter -mt-1">Masuk Dulu</h2>
              <Image
                src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761729760869-photo.jpg"
                alt="XONE Logo"
                width={50}
                height={50}
                className="mt-3 rounded-full"
              />
              <div>
                <p className="font-headline text-7xl font-bold mt-2 tracking-widest text-white text-center">XONE</p>
                <p className="text-center text-white text-base tracking-widest -mt-2">Systems</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleLogin} className="p-8 space-y-6">
            <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" placeholder="Masukan Username..." required />
            </div>
             <div className="space-y-2">
                <Label htmlFor="accessKey">Access Key</Label>
                <Input id="accessKey" name="accessKey" type="password" required />
            </div>
            
            <SubmitButton
              isSubmitting={isSubmitting}
              className="w-full h-12 text-md font-bold rounded-xl"
            >
              Log In
            </SubmitButton>

            <div className="relative">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-border/50" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">
                    Or
                    </span>
                </div>
            </div>

             <Button
                variant="secondary"
                onClick={handleAnonymousLogin}
                disabled={isSubmitting}
                className="w-full h-12 text-md font-bold rounded-xl"
              >
                Coba Mode Tamu
              </Button>
            
            <p className="text-center text-xs text-muted-foreground pt-4">
                Ga Punya Akses? <Link href="https://t.me/ibradecode" target="_blank" className="text-primary hover:underline">Beli Sekarang</Link>
            </p>
          </form>
        </div>
        <div className="text-center mt-6">
            <Logo className="h-8 w-auto mx-auto mb-2 rounded-full" />
             <p className="text-center text-xs text-muted-foreground">
              © {new Date().getFullYear()} Built By <Link href="https://t.me/ibradecode" target="_blank" className="text-primary hover:underline">Ibra Decode</Link> With Xeno Community
            </p>
        </div>
      </div>
    </div>
  );
}


export default function LoginPage() {
  return (
    <FirebaseClientProvider>
      <LoginPageContent />
    </FirebaseClientProvider>
  )
}
