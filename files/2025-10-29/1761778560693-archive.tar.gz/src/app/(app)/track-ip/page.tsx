import PageHeader from "@/components/shared/page-header";
import IpTrackerClient from "@/components/track-ip/ip-tracker-client";
import PageBanner from "@/components/shared/page-banner";

export default function TrackIpPage() {
    return (
        <div className="space-y-8">
            <PageBanner
                imageUrl="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761729843002-photo.jpg"
                altText="IP Tracking visualization"
                title="IP Address Tracker"
                subtitle="Locate and analyze any public IP address."
            />
            <IpTrackerClient />
        </div>
    );
}
