
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import BackgroundCanvas from "@/components/shared/background-canvas";
import { FirebaseClientProvider } from "@/firebase/client-provider";
import BottomNavbar from "@/components/layout/bottom-navbar";

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <FirebaseClientProvider>
      <div className="flex min-h-screen w-full bg-background">
        <BackgroundCanvas />
        <Sidebar />
        <div className="flex flex-1 flex-col pl-0 md:pl-72 relative z-10">
          <Header />
          <main className="flex-1 p-4 sm:p-6 md:p-8 lg:p-10 pb-28 md:pb-10">{children}</main>
          <BottomNavbar />
        </div>
      </div>
    </FirebaseClientProvider>
  );
}
