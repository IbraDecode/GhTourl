import PageHeader from "@/components/shared/page-header";
import DdosClient from "@/components/ddos-simulator/ddos-client";
import PageBanner from "@/components/shared/page-banner";

export default function DdosSimulatorPage() {
    return (
        <div className="space-y-8">
            <PageBanner
                imageUrl="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761729843002-photo.jpg"
                altText="DDoS Attack visualization"
                title="DDoS Simulator"
                subtitle="Visualize a Distributed Denial of Service attack. This is a visual simulation only."
            />
            <DdosClient />
        </div>
    );
}
