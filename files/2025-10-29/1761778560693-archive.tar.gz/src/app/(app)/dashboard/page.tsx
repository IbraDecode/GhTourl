
'use client';

import WelcomeBanner from "@/components/dashboard/welcome-banner";
import StatCard from "@/components/dashboard/stat-card";
import ActivityCharts from "@/components/dashboard/activity-charts";
import PageHeader from "@/components/shared/page-header";
import { User, Clock, Server, Star } from "lucide-react";
import { useUser, useDoc, useFirestore, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import GuestModeBanner from "@/components/dashboard/guest-mode-banner";

export default function DashboardPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  // For non-anonymous users, create a memoized reference to their user document.
  // For anonymous users, this will be null.
  const userDocRef = useMemoFirebase(() => {
    if (!firestore || !user || user.isAnonymous) {
      return null;
    }
    return doc(firestore, 'users', user.uid);
  }, [firestore, user]);

  // Use the useDoc hook with the potentially null document reference.
  const { data: userData } = useDoc<{ username: string, role: string }>(userDocRef);

  // Determine the username and plan based on user type and fetched data.
  const username = user?.isAnonymous 
    ? "Guest" 
    : userData?.username || user?.displayName || "User";
    
  const plan = user?.isAnonymous 
    ? "Guest" 
    : userData?.role || "Free";

  return (
    <div className="space-y-8 animate-fade-in-up">
      {user?.isAnonymous && <GuestModeBanner />}
      <PageHeader
        title="Dashboard"
        description="System overview and activity stats."
      />
      <WelcomeBanner username={username} />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <StatCard icon={User} title="Username" value={username} />
        <StatCard
          icon={Star}
          title="Current Plan"
          value={plan}
          valueClassName="capitalize"
        />
        <StatCard
          icon={Server}
          title="Server Status"
          value="Online"
          valueClassName="text-green-500"
        />
      </div>

      <ActivityCharts />
    </div>
  );
}
