import PageHeader from "@/components/shared/page-header";
import SenderManagement from "@/components/settings/sender-management";
import UserRoles from "@/components/settings/user-roles";
import { Separator } from "@/components/ui/separator";

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Settings"
        description="Manage WhatsApp senders and user access controls."
      />
      <div className="space-y-12">
        <SenderManagement />
        <Separator className="bg-border/50" />
        <UserRoles />
      </div>
    </div>
  );
}
