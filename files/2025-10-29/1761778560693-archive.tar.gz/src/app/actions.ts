'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { generateExploitContent, GenerateExploitContentInput } from '@/ai/flows/generate-exploit-content';
import { getNumberSpoofingSuggestions, NumberSpoofingSuggestionsInput } from '@/ai/flows/number-spoofing-suggestions';


// --- Authentication Actions ---

// This function is kept for potential future use with custom token logic,
// but is not actively used by the new Firebase anonymous sign-in flow.
export async function setAuthCookie(sessionData: string) {
  cookies().set('session', sessionData, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 24, // 1 day
    path: '/',
  });
}

export async function logout() {
  // Client-side logout is now preferred to clear Firebase state
  // This server action can be called as a fallback
  cookies().delete('session');
  redirect('/');
}

// --- AI Actions ---

export async function generateExploitContentAction(prevState: any, formData: FormData) {
  try {
    const input: GenerateExploitContentInput = {
      exploitType: formData.get('exploitType') as string,
      targetPlatform: formData.get('targetPlatform') as string,
      contentVariation: formData.get('contentVariation') as string,
    };
    
    if(!input.exploitType || !input.targetPlatform || !input.contentVariation) {
        return { error: 'All fields are required.' };
    }

    const result = await generateExploitContent(input);
    return { success: true, data: result };
  } catch (error) {
    console.error(error);
    return { error: 'Failed to generate content. Please try again.' };
  }
}

export async function getSpoofingSuggestionsAction(prevState: any, formData: FormData) {
    try {
        const input: NumberSpoofingSuggestionsInput = {
            currentMethods: formData.get('currentMethods') as string,
            targetPlatform: formData.get('targetPlatform') as 'iOS' | 'Android',
        };

        if(!input.currentMethods || !input.targetPlatform) {
            return { error: 'All fields are required.' };
        }

        const result = await getNumberSpoofingSuggestions(input);
        return { success: true, data: result };

    } catch (error) {
        console.error(error);
        return { error: 'Failed to get suggestions. Please try again.' };
    }
}
