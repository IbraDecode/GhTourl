import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { auth } from 'firebase-admin';

async function verifyToken(token: string) {
  try {
    // This part would need firebase-admin setup on the server-side, 
    // which is not directly supported in this environment for middleware.
    // The logic below simulates a valid session if a cookie exists.
    return { uid: 'some_user_id' }; // Mock verification
  } catch (error) {
    return null;
  }
}


export async function middleware(request: NextRequest) {
  const sessionCookie = request.cookies.get('session');
  const { pathname } = request.nextUrl;

  const isAuthenticated = !!sessionCookie?.value;

  const isAuthPage = pathname === '/';
  const isAppPage =
    pathname.startsWith('/dashboard') ||
    pathname.startsWith('/exploit-tool') ||
    pathname.startsWith('/track-ip') ||
    pathname.startsWith('/ddos-simulator') ||
    pathname.startsWith('/settings');

  if (isAuthPage) {
    if (isAuthenticated) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
    return NextResponse.next();
  }

  if (isAppPage) {
    if (!isAuthenticated) {
      return NextResponse.redirect(new URL('/', request.url));
    }
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - /api/auth/session (our session endpoint)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|api/auth/session).*)',
  ],
};
