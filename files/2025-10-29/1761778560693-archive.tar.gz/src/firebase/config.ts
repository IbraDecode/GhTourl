export const firebaseConfig = {
  "projectId": "studio-4891453311-14c35",
  "appId": "1:257942235677:web:7df745061d05ff5106b4f4",
  "apiKey": "AIzaSyB6J__Nf59K3Z0xCLmlFMsotwHCnDxNGK8",
  "authDomain": "studio-4891453311-14c35.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "257942235677"
};
