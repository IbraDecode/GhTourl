
'use client';
import {
  Auth, // Import Auth type for type hinting
  signInAnonymously,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getFirestore } from 'firebase/firestore';


/**
 * Initiates anonymous sign-in, optionally associating it with a specific user profile.
 * 
 * @param authInstance The Firebase Auth instance.
 * @param uidToAssign The UID from the api_keys document to assign to this session.
 * @param profileData The user profile data (username, role) to create in Firestore.
 */
export async function initiateAnonymousSignIn(
    authInstance: Auth, 
    uidToAssign?: string, 
    profileData?: { username: string, role: string }
) {
  try {
    const userCredential = await signInAnonymously(authInstance);
    
    // After sign-in, userCredential.user is the new anonymous user.
    // However, our logic relies on the onAuthStateChanged listener in FirebaseProvider
    // to handle the user object and redirection.
    // If we have profile data, we create/update the user document in Firestore.
    if (uidToAssign && profileData && authInstance.app) {
        const firestore = getFirestore(authInstance.app);
        const userDocRef = doc(firestore, "users", uidToAssign);
        await setDoc(userDocRef, {
            ...profileData,
            userId: uidToAssign, // ensure userId is set
        });
        
        // Also update the display name in the auth profile itself
        // Note: This only affects the `auth` object, not the firestore doc
        await updateProfile(userCredential.user, {
            displayName: profileData.username,
        });
    }

    // The onAuthStateChanged listener in FirebaseProvider will now fire,
    // find the user, and handle the redirection to the dashboard.
    // No need to manually router.push here.

  } catch (error) {
    console.error("Anonymous sign-in or profile creation failed:", error);
    // Re-throw the error so the calling component can handle it (e.g., show a toast)
    throw error;
  }
}
