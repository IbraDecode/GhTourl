import { config } from 'dotenv';
config();

import '@/ai/flows/generate-exploit-content.ts';
import '@/ai/flows/number-spoofing-suggestions.ts';