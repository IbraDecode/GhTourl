"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Globe, Loader2, Search } from "lucide-react";
import { Separator } from "@/components/ui/separator";

type IpInfo = {
  ip: string;
  city: string;
  region: string;
  country_name: string;
  org: string;
  asn: string;
  timezone: string;
  error?: boolean;
  reason?: string;
};

export default function IpTrackerClient() {
  const [ip, setIp] = useState("");
  const [ipInfo, setIpInfo] = useState<IpInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleTrackIp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ip) {
      toast({
        variant: "destructive",
        title: "Input Error",
        description: "Please enter an IP address.",
      });
      return;
    }
    setIsLoading(true);
    setIpInfo(null);
    try {
      const response = await fetch(`https://ipapi.co/${ip}/json/`);
      const data = await response.json();
      if (data.error) {
        throw new Error(data.reason);
      }
      setIpInfo(data);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Tracking Failed",
        description: error.message || "Could not fetch IP information.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const InfoRow = ({ label, value }: { label: string; value?: string }) => (
    <div className="flex justify-between items-center py-3 px-2 rounded-md transition-colors hover:bg-accent/50">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className="text-sm font-medium text-foreground">{value || "-"}</span>
    </div>
  )

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-2xl text-secondary">
          <Globe className="w-6 h-6" />
          IP Tracker
        </CardTitle>
        <CardDescription>
          Enter a public IP address to view its location, country, and ISP.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleTrackIp}>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              id="ip"
              value={ip}
              onChange={(e) => setIp(e.target.value)}
              placeholder="e.g., 8.8.8.8"
              className="flex-grow"
            />
            <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Search className="mr-2 h-4 w-4" />
              )}
              Track IP
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIp('8.8.8.8')}
              className="w-full sm:w-auto"
            >
              Demo
            </Button>
          </div>
        </CardContent>
      </form>
      {ipInfo && (
        <div className="p-6 border-t border-primary/20 bg-primary/5">
            <h3 className="font-headline text-lg text-secondary mb-4">
                Tracking Results for: {ipInfo.ip}
            </h3>
            <div className="space-y-1">
                <InfoRow label="IP Address" value={ipInfo.ip} />
                <Separator className="bg-border/50"/>
                <InfoRow label="City" value={ipInfo.city} />
                <Separator className="bg-border/50"/>
                <InfoRow label="Region" value={ipInfo.region} />
                <Separator className="bg-border/50"/>
                <InfoRow label="Country" value={ipInfo.country_name} />
                <Separator className="bg-border/50"/>
                <InfoRow label="ISP" value={ipInfo.org} />
                <Separator className="bg-border/50"/>
                <InfoRow label="ASN" value={ipInfo.asn} />
                <Separator className="bg-border/50"/>
                <InfoRow label="Timezone" value={ipInfo.timezone} />
            </div>
            <CardFooter className="pt-6 justify-end">
                <Button variant="ghost" asChild>
                    <a href={`https://www.google.com/maps/search/?api=1&query=${ipInfo.city},${ipInfo.country_name}`} target="_blank" rel="noopener noreferrer">View on Map</a>
                </Button>
            </CardFooter>
        </div>
      )}
    </Card>
  );
}
