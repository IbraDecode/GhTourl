
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

type StatCardProps = {
  icon: LucideIcon;
  title: string;
  value: string;
  valueClassName?: string;
};

export default function StatCard({
  icon: Icon,
  title,
  value,
  valueClassName,
}: StatCardProps) {
  return (
    <Card className="rounded-2xl transition-all duration-300 ease-out hover:shadow-primary/20 hover:shadow-lg hover:-translate-y-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-6 w-6 text-primary" />
      </CardHeader>
      <CardContent>
        <div
          className={cn(
            "text-3xl font-bold font-headline text-foreground truncate",
            valueClassName
          )}
        >
          {value}
        </div>
      </CardContent>
    </Card>
  );
}
