
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";
import Link from "next/link";

export default function GuestModeBanner() {
  return (
    <Alert className="bg-primary/10 border-primary/20 text-foreground">
      <Info className="h-5 w-5 !text-primary" />
      <AlertTitle className="font-bold text-primary">Anda Sedang Dalam Mode Tamu</AlertTitle>
      <AlertDescription className="mt-2 flex justify-between items-center">
        <span>
            Silahkan beli plan untuk menikmati semua fitur premium yang tersedia.
        </span>
        <Button asChild size="sm">
            <Link href="https://t.me/ibradecode" target="_blank">Beli Sekarang</Link>
        </Button>
      </AlertDescription>
    </Alert>
  );
}
