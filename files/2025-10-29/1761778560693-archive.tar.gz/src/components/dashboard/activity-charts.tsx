"use client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp } from "lucide-react";

const data = [
  { name: 'Mon', sent: 400, failed: 24 },
  { name: 'Tue', sent: 300, failed: 13 },
  { name: 'Wed', sent: 200, failed: 98 },
  { name: 'Thu', sent: 278, failed: 39 },
  { name: 'Fri', sent: 189, failed: 48 },
  { name: 'Sat', sent: 239, failed: 38 },
  { name: 'Sun', sent: 349, failed: 43 },
];

export default function ActivityCharts() {
  return (
    <Card className="rounded-2xl shadow-sm">
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center">
            <TrendingUp className="mr-3 h-7 w-7 text-secondary" />
            Weekly Activity
        </CardTitle>
        <CardDescription>Messages sent vs. failed over the last 7 days.</CardDescription>
      </CardHeader>
      <CardContent className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.5)" />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                borderColor: 'hsl(var(--border))',
                borderRadius: 'var(--radius)',
              }}
              cursor={{ fill: 'hsl(var(--accent))' }}
            />
            <Legend iconSize={10} wrapperStyle={{ fontSize: '0.8rem', paddingTop: '1rem' }} />
            <Bar dataKey="sent" fill="hsl(var(--primary))" name="Sent" radius={[4, 4, 0, 0]} />
            <Bar dataKey="failed" fill="hsl(var(--secondary))" name="Failed" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
