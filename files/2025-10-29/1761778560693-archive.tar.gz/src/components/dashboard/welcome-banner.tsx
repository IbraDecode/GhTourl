import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Button } from "../ui/button";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

type WelcomeBannerProps = {
  username: string;
};

export default function WelcomeBanner({ username }: WelcomeBannerProps) {
  const bannerImage = PlaceHolderImages.find((img) => img.id === "hero-banner");

  return (
    <div className="relative w-full h-64 rounded-2xl overflow-hidden shadow-lg bg-card border border-border/50">
      {bannerImage && (
        <Image
          src={bannerImage.imageUrl}
          alt={bannerImage.description}
          data-ai-hint={bannerImage.imageHint}
          fill
          className="object-cover opacity-20"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-card via-card/70 to-transparent"></div>
      <div className="absolute inset-0 flex flex-col items-start justify-center p-8 md:p-12 animate-fade-in-up">
        <h2 className="text-4xl md:text-5xl font-bold font-headline text-foreground">
          Welcome, <span className="text-primary">{username}</span>!
        </h2>
        <p className="mt-3 text-lg text-muted-foreground max-w-md">
          Your central command for next-gen automation is ready.
        </p>
        <Button asChild className="mt-6 rounded-full" size="lg">
            <Link href="/exploit-tool">
                Go to Exploit Tool
                <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
        </Button>
      </div>
    </div>
  );
}
