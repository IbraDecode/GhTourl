
'use client';

import { useState } from 'react';
import {
  collection,
  doc,
  deleteDoc,
  setDoc,
} from 'firebase/firestore';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Users, UserPlus, UserX, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type Role = 'premium' | 'vip' | 'partner' | 'owner';
type User = {
  id: string; // This will be the document ID (which is the same as userId)
  username: string;
  role: Role;
};

export default function UserRoles() {
  const [newUsername, setNewUsername] = useState('');
  const [newRole, setNewRole] = useState<Role>('premium');
  const [isAdding, setIsAdding] = useState(false);
  const { toast } = useToast();
  const firestore = useFirestore();

  const usersRef = useMemoFirebase(
    () => (firestore ? collection(firestore, 'users') : null),
    [firestore]
  );
  const { data: users, isLoading: isLoadingUsers } = useCollection<User>(usersRef);

  const handleAddUser = async () => {
    if (!newUsername) {
      toast({
        variant: 'destructive',
        title: 'Invalid User',
        description: 'Please enter a username.',
      });
      return;
    }
    if (!firestore) return;

    setIsAdding(true);
    try {
      // For simplicity, we'll use the username as the document ID (userId).
      // In a real app, this would likely be a unique ID generated elsewhere.
      const userId = newUsername.toLowerCase().replace(/\s/g, '_');
      const userDocRef = doc(firestore, 'users', userId);

      await setDoc(userDocRef, {
        userId: userId,
        username: newUsername,
        role: newRole,
      });

      setNewUsername('');
      toast({
        title: 'User Added',
        description: `${newUsername} has been added as ${newRole}.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error Adding User',
        description: 'Could not save the new user.',
      });
    } finally {
      setIsAdding(false);
    }
  };

  const handleRemoveUser = async (userId: string) => {
    if (!firestore) return;
    try {
      await deleteDoc(doc(firestore, 'users', userId));
      toast({
        title: 'User Removed',
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error Removing User',
        description: 'Could not remove the user.',
      });
    }
  };

  const getBadgeVariant = (role: Role) => {
    switch (role) {
      case 'owner':
        return 'destructive';
      case 'vip':
        return 'default';
      case 'partner':
        return 'secondary';
      case 'premium':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-2xl text-secondary">
          <Users className="w-6 h-6" />
          Access Control
        </CardTitle>
        <CardDescription>
          Manage user roles and permissions for the system.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            Add New User Role
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              placeholder="Enter username"
              disabled={isAdding}
            />
            <Select
              value={newRole}
              onValueChange={(v) => setNewRole(v as Role)}
              disabled={isAdding}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="owner">Owner</SelectItem>
                <SelectItem value="vip">VIP</SelectItem>
                <SelectItem value="partner">Partner</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={handleAddUser}
              className="w-full md:w-auto"
              disabled={isAdding}
            >
              {isAdding ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
              Add User
            </Button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            Current Users
          </h3>
          <div className="space-y-2">
            {isLoadingUsers && <div className="flex justify-center p-4"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}
            {users && users.map((user) => (
              <div
                key={user.id}
                className="flex items-center justify-between p-3 bg-accent/30 rounded-lg border border-border/50"
              >
                <div className="flex flex-col">
                  <span className="font-medium">{user.username}</span>
                  <Badge variant={getBadgeVariant(user.role)} className="w-fit mt-1 capitalize">
                    {user.role}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveUser(user.id)}
                >
                  <UserX className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
            {!isLoadingUsers && (!users || users.length === 0) && (
                <div className="text-center p-4 text-muted-foreground">
                    No users found.
                </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
