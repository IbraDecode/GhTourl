
'use client';

import { useState } from 'react';
import {
  collection,
  doc,
  serverTimestamp,
  deleteDoc,
  setDoc,
} from 'firebase/firestore';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Bot, Plus, Trash2, Loader2 } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

// Assuming WhatsAppSession is the type for documents in 'whatsapp_sessions'
type WhatsAppSession = {
  id: string;
  phoneNumber: string;
  status: 'Online' | 'Offline' | 'Connecting';
  lastConnected?: any;
};

export default function SenderManagement() {
  const [newSender, setNewSender] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const firestore = useFirestore();

  const sessionsRef = useMemoFirebase(
    () => (firestore ? collection(firestore, 'whatsapp_sessions') : null),
    [firestore]
  );
  const { data: senders, isLoading: isLoadingSenders } =
    useCollection<WhatsAppSession>(sessionsRef);

  const handleAddSender = async () => {
    if (!newSender || !/^\d+$/.test(newSender)) {
      toast({
        variant: 'destructive',
        title: 'Invalid Number',
        description: 'Please enter a valid phone number.',
      });
      return;
    }
    if (!firestore) return;

    setIsLoading(true);
    toast({
      title: 'Adding Sender...',
      description: `Pairing with ${newSender}.`,
    });

    try {
      const senderDocRef = doc(firestore, 'whatsapp_sessions', newSender);
      await setDoc(senderDocRef, {
        phoneNumber: newSender,
        sessionId: `session-${newSender}`,
        status: 'Online', // Simulate instant connection for now
        lastConnected: serverTimestamp(),
      });
      setNewSender('');
      toast({
        title: 'Sender Added',
        description: `${newSender} is now online.`,
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error Adding Sender',
        description: 'Could not save the new sender.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteSender = async (id: string) => {
    if (!firestore) return;
    try {
      await deleteDoc(doc(firestore, 'whatsapp_sessions', id));
      toast({
        title: 'Sender Removed',
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error Removing Sender',
        description: 'Could not remove the sender.',
      });
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-2xl text-secondary">
          <Bot className="w-6 h-6" />
          Sender Management
        </CardTitle>
        <CardDescription>
          Add, view, and remove WhatsApp sender sessions.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            Add New Sender
          </h3>
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              value={newSender}
              onChange={(e) => setNewSender(e.target.value)}
              placeholder="Enter phone number, e.g., 62812... "
              disabled={isLoading}
            />
            <Button
              onClick={handleAddSender}
              disabled={isLoading}
              className="w-full sm:w-auto"
            >
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Plus className="mr-2 h-4 w-4" />
              )}
              Add Sender
            </Button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            Active Senders
          </h3>
          <div className="border border-border/50 rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Number</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoadingSenders && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center">
                      <Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" />
                    </TableCell>
                  </TableRow>
                )}
                {senders &&
                  senders.map((sender) => (
                    <TableRow key={sender.id}>
                      <TableCell className="font-medium">
                        {sender.phoneNumber}
                      </TableCell>
                      <TableCell
                        className={
                          sender.status === 'Online'
                            ? 'text-green-400'
                            : 'text-muted-foreground'
                        }
                      >
                        {sender.status}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteSender(sender.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                 {!isLoadingSenders && (!senders || senders.length === 0) && (
                    <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                            No active senders.
                        </TableCell>
                    </TableRow>
                 )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
