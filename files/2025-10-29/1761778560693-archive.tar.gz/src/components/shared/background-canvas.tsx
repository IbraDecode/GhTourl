"use client";

import { useEffect, useRef } from "react";

export default function BackgroundCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w: number, h: number, particles: any[];
    const mouse = { x: 9999, y: 9999 };

    function init() {
      const dpr = window.devicePixelRatio || 1;
      w = canvas.width = window.innerWidth * dpr;
      h = canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
      
      const particleCount = 40;
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          ox: Math.random() * window.innerWidth,
          oy: Math.random() * window.innerHeight,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          radius: 2 + Math.random() * 2,
        });
      }
    }

    function animate() {
      ctx.clearRect(0, 0, w, h);
      
      const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim();
      
      particles.forEach((p) => {
        const dxMouse = p.x - mouse.x;
        const dyMouse = p.y - mouse.y;
        const distMouse = Math.sqrt(dxMouse * dxMouse + dyMouse * dyMouse);

        if (distMouse < 150) {
          const angle = Math.atan2(dyMouse, dxMouse);
          p.x += Math.cos(angle) * 2;
          p.y += Math.sin(angle) * 2;
        } else {
            const dxOrigin = p.x - p.ox;
            const dyOrigin = p.y - p.oy;
            if(Math.abs(dxOrigin) > 1 || Math.abs(dyOrigin) > 1) {
                p.x -= dxOrigin * 0.05;
                p.y -= dyOrigin * 0.05;
            } else {
                p.x += p.vx;
                p.y += p.vy;
            }
        }

        if (p.x < 0 || p.x > window.innerWidth) p.vx *= -1;
        if (p.y < 0 || p.y > window.innerHeight) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${primaryColor}, 0.5)`;
        ctx.fill();
      });

      ctx.strokeStyle = `hsla(${primaryColor}, 0.1)`;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 200) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      requestAnimationFrame(animate);
    }
    
    function handleMouseMove(e: MouseEvent) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }

    init();
    animate();
    window.addEventListener("resize", init);
    window.addEventListener("mousemove", handleMouseMove);

    return () => {
      window.removeEventListener("resize", init);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="bg"
      className="fixed top-0 left-0 -z-10 w-full h-full bg-transparent"
    ></canvas>
  );
}
