
'use client';
import { useState } from 'react';
import Image from "next/image";
import { cn } from '@/lib/utils';

type PageBannerProps = {
  imageUrl: string;
  altText: string;
  title: string;
  subtitle: string;
};

export default function PageBanner({ imageUrl, altText, title, subtitle }: PageBannerProps) {
  const [isTextVisible, setIsTextVisible] = useState(false);

  return (
    <div 
      className="relative w-full h-56 rounded-2xl overflow-hidden bg-card border border-border/50 cursor-pointer transition-all duration-300"
      onClick={() => setIsTextVisible(!isTextVisible)}
    >
        <Image
          src={imageUrl}
          alt={altText}
          fill
          className={cn(
            "object-cover transition-opacity duration-500",
            isTextVisible ? "opacity-20" : "opacity-40"
          )}
        />
        <div className={cn(
            "absolute inset-0 bg-gradient-to-r from-card via-card/70 to-transparent transition-opacity duration-500",
            isTextVisible ? "opacity-100" : "opacity-0"
        )}></div>
        <div 
            className={cn(
                "absolute inset-0 flex flex-col items-start justify-center p-8 md:p-12 transition-all duration-500",
                isTextVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            )}
        >
            <h1 className="text-3xl md:text-4xl font-bold font-headline text-foreground drop-shadow-lg">
                {title}
            </h1>
            <p className="mt-2 text-lg text-muted-foreground max-w-md drop-shadow-md">
                {subtitle}
            </p>
      </div>
      <div 
        className={cn(
            "absolute inset-0 rounded-2xl ring-2 ring-primary/50 transition-all duration-300",
            isTextVisible ? "shadow-2xl shadow-primary/20 ring-opacity-100" : "shadow-none ring-opacity-0"
        )}
      />
    </div>
  );
}
