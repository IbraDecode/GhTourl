'use client';

import { useFormStatus } from 'react-dom';
import { Button, type ButtonProps } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

export function SubmitButton({
  children,
  isSubmitting,
  ...props
}: ButtonProps & { children: React.ReactNode; isSubmitting?: boolean }) {
  const { pending } = useFormStatus();
  const isLoading = pending || isSubmitting;

  return (
    <Button type="submit" disabled={isLoading} {...props}>
      {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
      {isLoading ? 'Processing...' : children}
    </Button>
  );
}
