import { cn } from '@/lib/utils';
import Image from 'next/image';

export function Logo({ className }: { className?: string }) {
  return (
    <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761729801457-photo.jpg"
        alt="XONE Logo"
        width={40}
        height={40}
        className={cn("rounded-full", className)}
        priority
    />
  );
}
