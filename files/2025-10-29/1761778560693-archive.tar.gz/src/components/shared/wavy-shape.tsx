import { cn } from '@/lib/utils';

export function WavyShape({ className }: { className?: string }) {
    return (
        <div className={cn("absolute inset-x-0 top-0 h-full overflow-hidden", className)}>
            <svg
                viewBox="0 0 375 200"
                preserveAspectRatio="none"
                className="absolute w-full h-full"
                style={{ top: '-1px', left: '0', right: '0' }}
            >
                <path
                    d="M0 0 H 375 V 100 C 300 150, 200 80, 100 130 C 50 150, 20 120, 0 100 Z"
                    className="fill-primary"
                />
            </svg>
        </div>
    );
}
