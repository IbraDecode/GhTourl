
'use client';

import { useState, useRef, useEffect } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, SkipForward, SkipBack, Music } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';


const song = {
  title: "An Angel's Love",
  artist: "Breakbeat Mix",
  albumArt: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761739220774-photo.jpg",
  audioSrc: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761734096472-2_5193122331429471538.mp3",
};

export default function MusicPlayerWidget() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isPromptOpen, setIsPromptOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const setAudioData = () => setDuration(audio.duration);
    const updateProgress = () => setProgress(audio.currentTime);

    audio.addEventListener('loadedmetadata', setAudioData);
    audio.addEventListener('timeupdate', updateProgress);
    
    // Auto-toggle prompt animation
    const promptInterval = setInterval(() => {
        setIsPromptOpen(prev => !prev);
    }, 5000);

    return () => {
      audio.removeEventListener('loadedmetadata', setAudioData);
      audio.removeEventListener('timeupdate', updateProgress);
      clearInterval(promptInterval);
    };
  }, []);

  const togglePlayPause = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (isPlaying) {
      audioRef.current?.pause();
    } else {
      audioRef.current?.play();
    }
    setIsPlaying(!isPlaying);
  };
  
  const handleSliderChange = (value: number[]) => {
      if(audioRef.current) {
          audioRef.current.currentTime = value[0];
          setProgress(value[0]);
      }
  }

  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds)) return "0:00";
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const openDialog = () => setIsDialogOpen(true);
  
  const handleWidgetClick = (e: React.MouseEvent) => {
    // If the click is on the play button, let it handle the event
    const target = e.target as HTMLElement;
    if (target.closest('button')) {
      return;
    }
    // Otherwise, open the dialog
    openDialog();
  };

  return (
    <>
      <audio ref={audioRef} src={song.audioSrc} preload="metadata" />
      <div
        className="flex items-center gap-3 p-2 rounded-full bg-accent/50 border border-border/50 cursor-pointer hover:bg-accent/80 transition-colors"
        onClick={handleWidgetClick}
      >
        <Image
          src={song.albumArt}
          alt="Album Art"
          width={40}
          height={40}
          className="rounded-full"
        />

        <div className="flex-1 hidden sm:flex items-center" onClick={(e) => { e.stopPropagation(); setIsPromptOpen(!isPromptOpen)}}>
            <motion.div
                layout
                className="w-5 h-5 rounded-full border-2 border-primary flex items-center justify-center mr-2"
            >
                <motion.div
                    className="w-1.5 h-1.5 bg-primary rounded-full"
                    animate={{ scale: isPromptOpen ? 0 : 1 }}
                />
            </motion.div>
            <AnimatePresence>
            {isPromptOpen ? (
                <motion.p
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 'auto', transition: { delay: 0.1 } }}
                    exit={{ opacity: 0, width: 0 }}
                    className="text-xs text-primary font-medium whitespace-nowrap overflow-hidden"
                >
                    Before using the bug, play music first
                </motion.p>
            ) : (
                <motion.div
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: 'auto', transition: { delay: 0.1 } }}
                  exit={{ opacity: 0, width: 0 }}
                  className="overflow-hidden"
                >
                    <p className="font-medium text-sm text-foreground truncate">{song.title}</p>
                    <p className="text-xs text-muted-foreground">{song.artist}</p>
                </motion.div>
            )}
            </AnimatePresence>
        </div>


        <Button variant="ghost" size="icon" className="rounded-full h-10 w-10" onClick={togglePlayPause}>
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 hidden lg:inline-flex">
          <SkipForward className="w-5 h-5" />
        </Button>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md bg-card/95 backdrop-blur-xl border-border/50">
          <DialogHeader className="items-center text-center">
            <DialogTitle className="text-2xl font-headline">Now Playing</DialogTitle>
            <DialogDescription>{song.title} - {song.artist}</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center gap-6 py-6">
            <Image
              src={song.albumArt}
              alt="Album Art"
              width={200}
              height={200}
              className="rounded-2xl shadow-lg shadow-primary/20"
            />
            <div className="w-full space-y-4">
               <div className="w-full text-center">
                    <p className="text-xl font-bold text-foreground">{song.title}</p>
                    <p className="text-md text-muted-foreground">{song.artist}</p>
                </div>
              <Slider value={[progress]} max={duration || 1} onValueChange={handleSliderChange} />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{formatTime(progress)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
            <div className="flex items-center justify-center gap-4">
              <Button variant="ghost" size="icon" className="rounded-full h-14 w-14">
                <SkipBack className="w-6 h-6" />
              </Button>
              <Button variant="primary" size="icon" className="rounded-full h-20 w-20 shadow-lg shadow-primary/40" onClick={() => togglePlayPause()}>
                {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 fill-current" />}
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full h-14 w-14">
                <SkipForward className="w-6 h-6" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
