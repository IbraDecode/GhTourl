"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  ShieldCheck,
  Globe,
  Zap,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/shared/logo";

const navItems = [
  { href: "/dashboard", icon: Home, label: "Dashboard" },
  { href: "/exploit-tool", icon: ShieldCheck, label: "Exploit Tool" },
  { href: "/track-ip", icon: Globe, label: "IP Tracker" },
  { href: "/ddos-simulator", icon: Zap, label: "DDoS Simulator" },
  { href: "/settings", icon: Settings, label: "Settings" },
];

export default function Sidebar({ isMobile = false }: { isMobile?: boolean }) {
  const pathname = usePathname();

  return (
    <div className={cn(
        "h-full bg-card/80 backdrop-blur-lg border-r border-border/50",
        !isMobile && "fixed hidden md:flex md:flex-col md:w-72"
    )}>
      <div className="flex h-20 items-center px-8">
        <Link href="/dashboard" className="flex items-center gap-3 font-headline font-semibold text-xl text-foreground">
          <Logo className="h-8 w-auto text-primary" />
          <span className="text-2xl font-bold">XONE</span>
        </Link>
      </div>
      <nav className="flex-1 p-6 text-base font-medium">
        <ul className="space-y-3">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-4 rounded-xl px-4 py-3 text-muted-foreground transition-all duration-300 hover:text-foreground hover:bg-accent",
                  pathname.startsWith(item.href) && "bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground"
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <div className="mt-auto p-6 border-t border-border/50">
        <div className="text-xs text-center text-muted-foreground">
             <p>© {new Date().getFullYear()} Built By <Link href="https://t.me/ibradecode" target="_blank" className="text-primary/80 hover:underline">Ibra Decode</Link></p>
            <p>Next-gen automation.</p>
        </div>
      </div>
    </div>
  );
}
