
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, ShieldCheck, Globe, Zap, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/dashboard', icon: Home, label: 'Home' },
  { href: '/exploit-tool', icon: ShieldCheck, label: 'Exploit' },
  { href: '/track-ip', icon: Globe, label: 'IP Track' },
  { href: '/ddos-simulator', icon: Zap, label: 'DDoS' },
  { href: '/settings', icon: Settings, label: 'Settings' },
];

export default function BottomNavbar() {
  const pathname = usePathname();

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-20 bg-card/80 backdrop-blur-lg border-t border-border/50 md:hidden">
      <div className="grid h-full max-w-lg grid-cols-5 mx-auto">
        {navItems.map((item) => {
          const isActive = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className="inline-flex flex-col items-center justify-center px-2 hover:bg-accent/50 group transition-colors duration-300"
            >
              <div className={cn(
                  "p-2.5 rounded-full transition-all duration-300 mb-1",
                  isActive ? "bg-primary/20" : "bg-transparent"
              )}>
                <item.icon
                  className={cn(
                    'w-6 h-6 text-muted-foreground group-hover:text-foreground transition-colors duration-300',
                    isActive && 'text-primary'
                  )}
                />
              </div>
              <span
                className={cn(
                  'text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors duration-300',
                  isActive && 'text-primary'
                )}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
