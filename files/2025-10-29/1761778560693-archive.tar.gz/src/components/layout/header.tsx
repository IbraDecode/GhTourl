
"use client";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, Settings, User, Languages, Check } from "lucide-react";
import { useAuth, useUser } from "@/firebase";
import Link from "next/link";
import MusicPlayerWidget from "./music-player-widget";
import { useLanguage } from "@/context/language-context";

export default function Header() {
  const auth = useAuth();
  const { user } = useUser();
  const { language, setLanguage, t } = useLanguage();

  const handleLogout = () => {
    if (auth) {
      auth.signOut();
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-20 items-center justify-between gap-4 border-b border-border/50 bg-background/50 px-4 backdrop-blur-lg sm:px-8">
      
      <div className="flex flex-1">
        <MusicPlayerWidget />
      </div>

      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-12 w-12 rounded-full">
              <Avatar className="h-12 w-12 border-2 border-primary/50">
                <AvatarImage src={user?.photoURL || "https://i.pravatar.cc/150?u=xone"} alt={user?.displayName || "Anonymous User"} />
                <AvatarFallback>{user?.displayName?.charAt(0) || 'A'}</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">{user?.isAnonymous ? t('guestUser') : (user?.displayName || t('user'))}</p>
                <p className="text-xs leading-none text-muted-foreground">
                  {user?.uid}
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
               <Link href="/dashboard"><User className="mr-2 h-4 w-4" /><span>{t('profile')}</span></Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
                <Link href="/settings"><Settings className="mr-2 h-4 w-4" /><span>{t('settings')}</span></Link>
            </DropdownMenuItem>
             <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                    <Languages className="mr-2 h-4 w-4" />
                    <span>{t('language')}</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                    <DropdownMenuItem onClick={() => setLanguage('en')}>
                        <span className="w-4 h-4 mr-2">{language === 'en' && <Check size={16} />}</span>
                        English
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLanguage('id')}>
                         <span className="w-4 h-4 mr-2">{language === 'id' && <Check size={16} />}</span>
                        Bahasa Indonesia
                    </DropdownMenuItem>
                </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                <LogOut className="mr-2 h-4 w-4" />
                <span>{t('logout')}</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
