"use client";

import { useState, useRef, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Zap, Play, Copy } from "lucide-react";

export default function DdosClient() {
  const [target, setTarget] = useState("https://example.com");
  const [time, setTime] = useState("15");
  const [isSimulating, setIsSimulating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const { toast } = useToast();

  const startSim = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    toast({
      title: "Simulation Started",
      description: `Simulating attack on ${target} for ${time} seconds.`,
    });

    setIsSimulating(true);

    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    
    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvas.clientWidth * dpr;
    canvas.height = canvas.clientHeight * dpr;
    ctx.scale(dpr, dpr);

    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    
    const parts: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
    }[] = [];
    for (let i = 0; i < 100; i++) {
      parts.push({
        x: w / 2,
        y: h / 2,
        vx: (Math.random() - 0.5) * 12,
        vy: (Math.random() - 0.5) * 12,
        life: 60 + Math.random() * 60,
      });
    }

    const animate = () => {
      ctx.fillStyle = "rgba(10, 25, 47, 0.2)";
      ctx.fillRect(0, 0, w, h);
      parts.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
        if (p.life <= 0 || p.x < 0 || p.x > w || p.y < 0 || p.y > h) {
          parts[i] = {
            x: w / 2,
            y: h / 2,
            vx: (Math.random() - 0.5) * 12,
            vy: (Math.random() - 0.5) * 12,
            life: 60 + Math.random() * 60,
          };
        }
        ctx.beginPath();
        ctx.fillStyle = `rgba(0, 224, 239, ${Math.max(0, p.life / 120)})`;
        ctx.arc(p.x, p.y, Math.max(1, p.life / 20), 0, Math.PI * 2);
        ctx.fill();
      });
      animationRef.current = requestAnimationFrame(animate);
    };

    if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
    }
    animate();

    setTimeout(() => {
        if(animationRef.current) cancelAnimationFrame(animationRef.current);
        setIsSimulating(false);
        toast({
            title: "Simulation Finished",
        });
    }, parseInt(time) * 1000);
  };
  
  const copyTarget = () => {
    navigator.clipboard.writeText(target);
    toast({ title: "Target URL copied!" });
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-2xl text-secondary">
          <Zap className="w-6 h-6" />
          DDoS Attack Simulator
        </CardTitle>
        <CardDescription>
          This tool provides a visual-only simulation of a DDoS attack. No
          actual network traffic is generated.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <Input
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="https://example.com"
          />
          <Input
            type="number"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            placeholder="Duration (seconds)"
            className="sm:w-48"
          />
        </div>
        <div className="relative h-64 w-full rounded-lg bg-background/80 border border-border/50 overflow-hidden">
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full"></canvas>
            {!isSimulating && (
                <div className="absolute inset-0 flex items-center justify-center">
                    <p className="text-muted-foreground">Ready to simulate...</p>
                </div>
            )}
        </div>
        <div className="flex flex-wrap gap-4">
            <Button onClick={startSim} disabled={isSimulating}>
                <Zap className="mr-2 h-4 w-4" />
                {isSimulating ? "Simulating..." : "Start Simulation"}
            </Button>
            <Button onClick={startSim} disabled={isSimulating} variant="outline">
                <Play className="mr-2 h-4 w-4" />
                Replay
            </Button>
            <Button onClick={copyTarget} variant="ghost">
                <Copy className="mr-2 h-4 w-4" />
                Copy Target
            </Button>
        </div>
      </CardContent>
    </Card>
  );
}
