# **App Name**: XONE Systems

## Core Features:

- WhatsApp Sender Management: Manage WhatsApp sender sessions (add, list, delete) via Telegram commands for automated messaging.
- Key Management: Generate, list, and delete API keys for user authentication and authorization to access XONE Systems features.
- Access Control: Manage user roles (owner, staff, partner) with commands to add or remove users from specific roles.
- Global Cooldown System: Implement a cooldown period between actions, adjustable via Telegram command, to prevent abuse and manage system load.
- Track IP: Geolocation lookup based on entered IP address to display its location.
- DDOS simulator: DDOS website using browser based javascript and simulate the website attack with canvas animations
- WhatsApp Exploit Tool: Trigger various prebuilt functions and techniques for WhatsApp, offering multiple modes (Andros, iOS, Invisible iPhone). This tool should allow configuration to change number spoofing and customizability of content based exploits to affect multiple platforms

## Style Guidelines:

- Primary color: Cyan (#00E0EF) for a futuristic and high-tech feel.
- Background color: Dark navy blue (#0A192F) to create contrast and focus.
- Accent color: Electric blue (#7DF9FF) for highlights and active elements.
- Headline font: 'Space Grotesk' (sans-serif) for headlines; Body font: 'Inter' (sans-serif) for body text.
- Use modern, minimalist icons to represent different functions and features.
- A clean, modular layout with clear information hierarchy to allow for easy navigation.
- Subtle animations on button hover and page transitions to improve interactivity.