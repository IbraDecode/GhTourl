import os
import subprocess
from PyroUbot import *
import requests

__MODULE__ = "ʙʀᴀᴛ"
__HELP__ =  """
<b>💠 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙʀᴀᴛ 💠 </b>

<blockquote><b>💠 ᴘᴇʀɪɴᴛᴀʜ:
ᚗ <code>{0}brat [text]</code>
⊷ Untuk Membuat Gambar Text Seperti Tren Tiktok</b></blockquote>

<blockquote><b>💠 ᴘᴇʀɪɴᴛᴀʜ:
ᚗ <code>{0}bratvideo [text]</code>
⊷ Untuk Membuat Gambar Text video Seperti Tren Tiktok</b></blockquote>

"""

def get_brat_image(text):
    url = "https://fast-flash-api-rest.vercel.app/imagecreator/brat"
    params = {
        "text": text,
        "apikey": "msbrewc"
    }
    for attempt in range(3):  # Retry up to 3 times
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()

            if response.headers.get("Content-Type", "").startswith("image/"):
                return response.content
            else:
                return None
        except requests.exceptions.RequestException:
            if attempt == 2:  # Last attempt
                return None
            continue
        
@PY.UBOT("brat")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("💠 Gunakan perintah .brat <teks> untuk membuat gambar.")
        return

    request_text = args[1]
    await message.reply_text("💠 Sedang memproses, mohon tunggu...")

    image_content = get_brat_image(request_text)
    if image_content:
        temp_file_jpg = "img.jpg"
        temp_file_webp = "img.webp"
        with open(temp_file_jpg, "wb") as f:
            f.write(image_content)

        # Convert to webp using ffmpeg
        try:
            subprocess.run(["ffmpeg", "-i", temp_file_jpg, "-vf", "scale=512:512", temp_file_webp], check=True, capture_output=True)
            await message.reply_sticker(sticker=temp_file_webp)
        except subprocess.CalledProcessError:
            await message.reply_text("Gagal mengonversi ke sticker.")
        finally:
            os.remove(temp_file_jpg)
            if os.path.exists(temp_file_webp):
                os.remove(temp_file_webp)
    else:
        await message.reply_text("apikey sedang bermasalah....")

def get_brat_video(text):
    url = "https://fast-flash-api-rest.vercel.app/imagecreator/bratvideo"
    params = {
        "text": text,
        "apikey": "msbrewc"
    }
    for attempt in range(3):  # Retry up to 3 times
        try:
            response = requests.get(url, params=params, timeout=30)  # Longer timeout for video
            response.raise_for_status()

            # For video, check if content is present
            if response.content:
                return response.content
            else:
                return None
        except requests.exceptions.RequestException:
            if attempt == 2:  # Last attempt
                return None
            continue
        
@PY.UBOT("bratvideo")
@PY.UBOT("bratvid")
async def _(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("gunakan perintah .bratvideo <teks> untuk membuat video.")
        return

    request_text = args[1]
    await message.reply_text("💠 sedang memproses, mohon tunggu...")

    mp4_content = get_brat_video(request_text)
    if mp4_content:
        temp_file = "brat.mp4"
        with open(temp_file, "wb") as f:
            f.write(mp4_content)

        await message.reply_video(video=temp_file, caption="Video brat berhasil dibuat!", supports_streaming=True)

        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah....")
