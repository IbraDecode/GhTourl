module.exports = {
  domain: "https://hanzpublikkk.xyzraa.biz.id", // Ubah jadi Domain panel Mu !!!
  port: "4055" // Ubah Jadi Port Panel Mu !!!
};