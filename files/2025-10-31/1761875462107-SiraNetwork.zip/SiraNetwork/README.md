# SiraNetwork Panel

This is a Next.js-based control panel for orchestrating network security tasks.

## How the API System Works

This application is a **control panel (UI)**. It does not contain any attack logic itself. Its purpose is to send commands to your own API servers, which you must build and host separately. The servers you add to the "4pi Server List" are expected to be your attack servers.

### API Server Architecture

Here is the API contract that your external servers must adhere to for this panel to work correctly.

**1. API Endpoint**

Each of your servers must expose the following endpoint:

- **Method**: `POST`
- **Path**: `/attack`

**Example**: If your server's URL is `https://my-attack-api.com`, the panel will send requests to `https://my-attack-api.com/attack`.

**2. Request Body**

The panel will send a JSON object in the `POST` request body with the following structure:

```json
{
  "target": "string",   // The target's IP address or domain
  "port": "number",     // The target's port
  "duration": "number", // The attack duration in seconds
  "method": "string"    // The attack method (e.g., "UDP", "TCP")
}
```

**3. Server Responsibilities**

Your API server's job is to:
1.  Receive the `POST` request on the `/attack` endpoint.
2.  Parse and validate the JSON body.
3.  Based on the `method` field, initiate the corresponding attack logic that you have implemented.
4.  **Immediately** send a response back to the control panel to confirm the command was received. Do not wait for the attack to finish.

**4. Expected Response**

To confirm that the command has been accepted and is being processed, your server should respond with:

- **Status Code**: `202` (Accepted)
- **Response Body** (Example):
  ```json
  {
    "message": "Attack command received and initiated."
  }
  ```

By following this architecture, the control panel remains fast and responsive, acting as a command center that delegates the actual work to your fleet of API servers.
