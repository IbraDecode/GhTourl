
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const targetUrl = searchParams.get('url');

  if (!targetUrl) {
    return NextResponse.json({ message: 'No url provided' }, { status: 400 });
  }

  try {
    // Forward the request to the target URL
    const res = await fetch(targetUrl, { 
      headers: {
        ...request.headers,
        'host': new URL(targetUrl).host,
      },
      signal: AbortSignal.timeout(8000) 
    });

    // Create a new response with the fetched data
    const response = new NextResponse(res.body, {
      status: res.status,
      statusText: res.statusText,
      headers: res.headers,
    });

    // Remove the content-encoding header to avoid decompression issues
    response.headers.delete('content-encoding');

    return response;

  } catch (error) {
    console.error(`[PROXY ERROR] Failed to fetch ${targetUrl}:`, error);
    return NextResponse.json({ message: `Proxy error: ${error}` }, { status: 500 });
  }
}
