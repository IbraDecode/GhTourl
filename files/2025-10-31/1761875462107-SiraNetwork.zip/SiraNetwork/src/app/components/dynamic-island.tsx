"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { Pause, Play, Music } from "lucide-react";
import { DashboardState } from "@/lib/state";
import { cn } from "@/lib/utils";
import type { MusicPlayerState } from "@/lib/types";
import { motion, AnimatePresence } from "framer-motion";

export function DynamicIsland() {
  const { musicPlayer, setMusicPlayer } = DashboardState.useState();
  const { isPlaying, isExpanded, track, isVisible, isMinimized } = musicPlayer;
  const audioRef = useRef<HTMLAudioElement>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  const minimizeTimerRef = useRef<NodeJS.Timeout | null>(null);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);

  const hasContent = !!track;

  const clearAllTimers = () => {
    if (minimizeTimerRef.current) {
      clearTimeout(minimizeTimerRef.current);
      minimizeTimerRef.current = null;
    }
    if (hideTimerRef.current) {
      clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
  };

  const startTimers = (state: MusicPlayerState) => {
    clearAllTimers();
    if (state.isPlaying) {
      // If playing and in default state, set timer to minimize
      if (!state.isExpanded && !state.isMinimized) {
        minimizeTimerRef.current = setTimeout(() => {
          setMusicPlayer(prev => ({ ...prev, isMinimized: true }));
        }, 5000);
      }
    } else if (hasContent) { // If paused
      // Set timer to minimize after 2s
      minimizeTimerRef.current = setTimeout(() => {
        setMusicPlayer(prev => ({ ...prev, isMinimized: true, isExpanded: false }));
      }, 2000);
      
      // Set timer to hide completely after 7s
      hideTimerRef.current = setTimeout(() => {
        setMusicPlayer(prev => ({ ...prev, isVisible: false }));
      }, 7000);
    }
  }

  useEffect(() => {
    if (track && audioRef.current) {
        if (isPlaying) {
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
        } else {
            audioRef.current.pause();
        }
    }
  }, [isPlaying, track]);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!track) return;
    
    const newState: MusicPlayerState = {
        ...musicPlayer,
        isPlaying: !musicPlayer.isPlaying,
        isVisible: true,
        isMinimized: false,
        isExpanded: false
    };
    setMusicPlayer(() => newState);
    startTimers(newState);
  };

  const toggleExpand = () => {
    if(!track || isMinimized) return;

    const newState: MusicPlayerState = { 
        ...musicPlayer, 
        isExpanded: !musicPlayer.isExpanded, 
        isMinimized: false 
    };
    setMusicPlayer(() => newState);
    startTimers(newState);
  };
  
  const handleWakeUp = () => {
    if(isMinimized) {
        const newState = {...musicPlayer, isMinimized: false, isExpanded: false, isVisible: true};
        setMusicPlayer(() => newState);
        startTimers(newState);
    }
  }

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
        setDuration(audioRef.current.duration);
        setProgress(audioRef.current.currentTime);
        // When a new track is loaded and starts playing, start the timers
        if (isPlaying) {
            startTimers(musicPlayer);
        }
    }
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (audioRef.current) {
      audioRef.current.currentTime = Number(e.target.value);
      // Restart timers on interaction
      startTimers(musicPlayer);
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time) || time === 0) return "00:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const islandWidth = isExpanded ? '90vw' : isMinimized ? '3rem' : '15rem';
  const islandHeight = isExpanded ? '9rem' : isMinimized ? '3rem' : '3rem';

  return (
    <>
      <AnimatePresence>
        {isVisible && hasContent && (
           <motion.div
            className={cn(
                "fixed inset-x-0 top-4 z-50 flex pointer-events-none",
                isMinimized ? "justify-start pl-4" : "justify-center"
            )}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
           >
            <motion.div
              layout
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              onClick={isMinimized ? handleWakeUp : toggleExpand}
              className={cn(
                "flex items-center bg-black text-white rounded-full shadow-2xl",
                "pointer-events-auto cursor-pointer"
              )}
              style={{
                width: islandWidth,
                height: islandHeight,
                maxWidth: isExpanded ? '24rem' : undefined,
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
              }}
            >
              <AnimatePresence mode="wait" initial={false}>
                {isMinimized ? (
                    <motion.div
                        key="minimized"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1, transition: { delay: 0.1 } }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="w-full h-full flex items-center justify-center"
                    >
                        <Music size={20} className="text-neutral-400" />
                    </motion.div>
                ) : isExpanded ? (
                  // Expanded View
                  <motion.div
                    key="expanded"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.2 } }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col w-full h-full items-center justify-between p-4 text-white"
                  >
                    <div className="flex w-full items-center justify-between">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <Image src={track.albumArt} alt="Album Art" width={40} height={40} className="rounded-md shrink-0" />
                        <div className="overflow-hidden">
                          <p className="font-bold text-sm leading-tight truncate">{track.title}</p>
                          <div className="flex items-center gap-1.5">
                            {isPlaying && <Music size={12} className="text-green-400 animate-pulse" />}
                            <p className="text-xs text-neutral-300 leading-tight truncate">{track.artist}</p>
                          </div>
                        </div>
                      </div>
                      <button onClick={togglePlay} className="p-2 rounded-full hover:bg-white/10 shrink-0">
                        {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                      </button>
                    </div>
                    <div className="w-full">
                      <input
                          type="range"
                          min="0"
                          max={duration}
                          value={progress}
                          onClick={(e) => e.stopPropagation()}
                          onChange={handleSeek}
                          className="w-full h-1 bg-neutral-600 rounded-lg appearance-none cursor-pointer range-sm"
                          style={{ backgroundSize: `${(progress / (duration || 1)) * 100}% 100%`}}
                      />
                      <div className="flex justify-between text-xs text-neutral-400 mt-1">
                        <span>{formatTime(progress)}</span>
                        <span>{formatTime(duration)}</span>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  // Collapsed View with Content
                  <motion.div
                    key="collapsed"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.2 } }}
                    exit={{ opacity: 0 }}
                    className="flex items-center justify-between w-full h-full px-3"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                        <Image src={track.albumArt} alt="Album Art" width={32} height={32} className="rounded-md shrink-0" />
                        <p className="font-semibold text-sm truncate">{track.title}</p>
                    </div>
                    <div className="flex items-center shrink-0">
                      {isPlaying && <Music size={16} className="text-green-400 animate-pulse mx-2" />}
                      <button onClick={togglePlay} className="p-1">
                        {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {track && (
        <audio
          ref={audioRef}
          src={track.audioSrc}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={() => {
            const newState = {...musicPlayer, isPlaying: false};
            setMusicPlayer(() => newState);
            startTimers(newState);
          }}
          onPlay={() => startTimers({ ...musicPlayer, isPlaying: true })}
        />
      )}
      <style jsx>{`
        input[type="range"]::-webkit-slider-runnable-track {
          background: #404040;
        }
        input[type="range"] {
          background-image: linear-gradient(to right, #10B981, #10B981);
          background-repeat: no-repeat;
        }
        input[type="range"]::-webkit-slider-thumb {
         -webkit-appearance: none;
          height: 12px;
          width: 12px;
          border-radius: 50%;
          background: #ffffff;
          margin-top: -4px;
        }
      `}</style>
    </>
  );
}
