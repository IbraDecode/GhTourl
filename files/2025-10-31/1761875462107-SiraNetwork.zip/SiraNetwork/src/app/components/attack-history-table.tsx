
"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Attack } from "@/lib/types";
import Image from "next/image";

interface AttackHistoryTableProps {
  attacks: Attack[];
}

export function AttackHistoryTable({ attacks }: AttackHistoryTableProps) {
  return (
    <Card className="relative overflow-hidden">
      <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810454405-photo.jpg"
        alt="Attack History Background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="digital data stream"
      />
      <div className="relative">
        <CardHeader>
          <CardTitle>Attack History</CardTitle>
          <CardDescription>
            The panel sends commands but does not receive attack history.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableBody>
                <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                        No attack history to display.
                    </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </div>
    </Card>
  );
}
