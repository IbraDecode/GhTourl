
"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Attack } from "@/lib/types";
import Image from "next/image";

interface OngoingAttacksProps {
  attacks: Attack[];
}

export function OngoingAttacks({ attacks }: OngoingAttacksProps) {
  return (
    <Card className="relative overflow-hidden">
       <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810438881-photo.jpg"
        alt="Ongoing attacks background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="digital matrix"
      />
      <div className="relative">
        <CardHeader>
          <CardTitle>Attack Status</CardTitle>
          <CardDescription>
            The panel sends commands but does not receive real-time status.
          </CardDescription>
        </CardHeader>
        <CardContent>
           <div className="flex h-24 items-center justify-center rounded-md border border-dashed bg-card/50 backdrop-blur-sm">
              <p className="text-sm text-muted-foreground">No real-time attack data available.</p>
          </div>
        </CardContent>
      </div>
    </Card>
  );
}
