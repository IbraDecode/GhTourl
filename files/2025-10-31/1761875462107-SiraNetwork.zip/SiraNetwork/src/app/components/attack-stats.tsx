
"use client"

import { Card } from "@/components/ui/card"
import type { LiveStats } from "@/lib/types"
import { Activity, CheckCircle, Zap, TrendingUp, AlertTriangle } from "lucide-react"

interface AttackStatsProps {
  stats: LiveStats;
  ongoingAttacks: boolean;
}

export function AttackStats({ stats, ongoingAttacks }: AttackStatsProps) {
  
  if (!ongoingAttacks) {
    return (
     <div className="grid gap-6 md:grid-cols-3">
      <Card className="flex flex-col items-center justify-center text-center p-6 bg-card/50 backdrop-blur-sm">
          <Zap className="h-8 w-8 text-muted-foreground mb-2"/>
          <p className="text-2xl font-bold">IDLE</p>
          <p className="text-xs text-muted-foreground">Waiting for attack command...</p>
      </Card>
      <Card className="flex flex-col items-center justify-center text-center p-6 bg-card/50 backdrop-blur-sm">
          <Activity className="h-8 w-8 text-muted-foreground mb-2"/>
          <p className="text-2xl font-bold">N/A</p>
          <p className="text-xs text-muted-foreground">Requests/sec</p>
      </Card>
       <Card className="flex flex-col items-center justify-center text-center p-6 bg-card/50 backdrop-blur-sm">
          <CheckCircle className="h-8 w-8 text-muted-foreground mb-2"/>
          <p className="text-2xl font-bold">N/A</p>
          <p className="text-xs text-muted-foreground">Success Rate</p>
      </Card>
     </div>
    )
  }

  const successRate = stats.totalRequests > 0 
    ? ((stats.successfulRequests / stats.totalRequests) * 100).toFixed(1) 
    : "0.0";
    
  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  }

  return (
     <div className="grid gap-6 md:grid-cols-3">
      <Card className="flex flex-col items-center justify-center text-center p-6 bg-green-900/20 backdrop-blur-sm border-green-500/30">
          <TrendingUp className="h-8 w-8 text-green-400 mb-2"/>
          <p className="text-2xl font-bold">{formatNumber(stats.totalRequests)}</p>
          <p className="text-xs text-green-300/80">Total Requests</p>
      </Card>
      <Card className="flex flex-col items-center justify-center text-center p-6 bg-blue-900/20 backdrop-blur-sm border-blue-500/30">
          <Activity className="h-8 w-8 text-blue-400 mb-2"/>
          <p className="text-2xl font-bold">{formatNumber(stats.rps)}</p>
          <p className="text-xs text-blue-300/80">Requests/sec</p>
      </Card>
       <Card className="flex flex-col items-center justify-center text-center p-6 bg-yellow-900/20 backdrop-blur-sm border-yellow-500/30">
          <CheckCircle className="h-8 w-8 text-yellow-400 mb-2"/>
          <p className="text-2xl font-bold">{successRate}%</p>
          <p className="text-xs text-yellow-300/80">Success Rate</p>
      </Card>
     </div>
  )
}

    