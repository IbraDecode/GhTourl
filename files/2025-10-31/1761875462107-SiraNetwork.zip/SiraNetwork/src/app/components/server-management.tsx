
"use client";

import { useState } from "react";
import { Plus, Trash2, Network, Loader, CircleDot, Circle, XCircle, Info } from "lucide-react";
import Image from "next/image";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import type { Server } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ServerManagementProps {
  servers: Server[];
  onAddServer: (url: string) => void;
  onDeleteServer: (id: string) => void;
  onTestServers: () => void;
}

const statusIcons = {
  Untested: <Circle className="h-3 w-3 text-muted-foreground" />,
  Online: <CircleDot className="h-3 w-3 text-green-500" />,
  Offline: <XCircle className="h-3 w-3 text-red-500" />,
  Testing: <Loader className="h-3 w-3 animate-spin" />,
};

const statusColors: { [key in Server['status']]: "default" | "secondary" | "destructive" | "outline"} = {
  Untested: "secondary",
  Online: "default",
  Offline: "destructive",
  Testing: "outline",
}

export function ServerManagement({
  servers,
  onAddServer,
  onDeleteServer,
  onTestServers,
}: ServerManagementProps) {
  const { toast } = useToast();

  const handleDisabledClick = () => {
    toast({
        title: "Read-Only",
        description: "Server management is handled via the servers.json file. Please ask me to make changes.",
    });
  };
  
  return (
    <Card className="relative overflow-hidden">
        <Image
        src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761806253514-photo.jpg"
        alt="Server management background"
        fill
        className="object-cover opacity-10"
        data-ai-hint="server circuit"
      />
      <div className="relative z-10">
        <CardHeader>
          <CardTitle>4pi Server List</CardTitle>
          <CardDescription>
            Your API endpoints, loaded from <code className="font-mono p-1 bg-muted rounded-sm text-xs">servers.json</code>.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex gap-2">
            <Input
              placeholder="Ask me to add a server to servers.json"
              className="bg-background/80"
              disabled
            />
            <Button onClick={handleDisabledClick} size="icon" disabled>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="h-64 rounded-md border bg-card/50 backdrop-blur-sm p-2">
             <ScrollArea className="h-full w-full">
               {servers.length > 0 ? (
                 <div className="space-y-2">
                   {servers.map((server) => (
                     <div key={server.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50">
                       <div className="flex items-center gap-2 flex-grow min-w-0">
                         {statusIcons[server.status]}
                         <span className="truncate text-sm">{server.url}</span>
                       </div>
                       <Badge variant={statusColors[server.status]} className="hidden sm:inline-flex">{server.status}</Badge>
                       <Button
                         variant="ghost"
                         size="icon"
                         className="h-8 w-8 shrink-0"
                         onClick={handleDisabledClick}
                         disabled
                       >
                         <Trash2 className="h-4 w-4" />
                       </Button>
                     </div>
                   ))}
                 </div>
               ) : (
                 <div className="flex flex-col items-center justify-center h-full text-sm text-muted-foreground text-center">
                    <Info className="h-6 w-6 mb-2" />
                   <p>No servers found in <code className="font-mono p-1 bg-muted rounded-sm text-xs">servers.json</code>.</p>
                   <p className="text-xs">Ask me to add your first API server!</p>
                 </div>
               )}
             </ScrollArea>
           </div>
        </CardContent>
        <CardFooter>
          <Button onClick={onTestServers} className="w-full" variant="outline">
            <Network /> Test All Servers
          </Button>
        </CardFooter>
      </div>
    </Card>
  );
}
