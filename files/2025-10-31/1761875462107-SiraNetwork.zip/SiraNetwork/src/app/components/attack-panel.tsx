
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import {
  ArrowRightLeft,
  Clock,
  Target,
  Zap,
  ListFilter,
  Globe,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Attack } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

const attackSchema = z.object({
  target: z.string().min(1, "Target is required."),
  port: z.coerce.number().min(1, "Port is required.").max(65535),
  duration: z.coerce.number().min(10, "Duration must be at least 10s.").max(3600),
  method: z.string().min(1, "Method is required."),
});

type AttackFormValues = z.infer<typeof attackSchema>;

interface AttackPanelProps {
  onStartAttack: (data: Omit<Attack, "id" | "startTime" | "status">) => void;
  serverCount: number;
}

// Synchronized with user's server.js commandMap
const attackMethods = [
    "ninja", "mix", "strike", "tls", "flood", 
    "tlskill", "storm", "destroy", "thunder", "bypass", 
    "cf-flood", "http-vip", "uam", "tornado", "raw-mix", 
    "drown", "cookie", "tls-slow"
];


export function AttackPanel({ onStartAttack, serverCount }: AttackPanelProps) {
  const { toast } = useToast();
  const form = useForm<AttackFormValues>({
    resolver: zodResolver(attackSchema),
    defaultValues: {
      target: "",
      port: 80,
      duration: 60,
      method: "ninja",
    },
  });

  const handleSubmit = (data: AttackFormValues) => {
     if (serverCount === 0) {
      toast({
        title: "No API Servers",
        description: "Please add and test at least one API server to launch an attack.",
        variant: "destructive",
      });
      return;
    }
    onStartAttack(data);
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit)}
        className="space-y-6"
      >
        <h1 className="text-2xl font-bold text-center font-headline">SiraXDDoS</h1>
        <div className="grid gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="target"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Target</FormLabel>
                <div className="relative">
                  <Target className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <FormControl>
                    <Input placeholder="e.g., https://example.com" {...field} className="pl-9" />
                  </FormControl>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="port"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Port</FormLabel>
                 <div className="relative">
                  <ArrowRightLeft className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <FormControl>
                    <Input type="number" placeholder="e.g., 443" {...field} className="pl-9" />
                  </FormControl>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="duration"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Duration (seconds)</FormLabel>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <FormControl>
                    <Input type="number" placeholder="e.g., 60" {...field} className="pl-9" />
                  </FormControl>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="method"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Method</FormLabel>
                <div className="relative">
                  <ListFilter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10" />
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="pl-9">
                        <SelectValue placeholder="Select an attack method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {attackMethods.map((method) => (
                        <SelectItem key={method} value={method}>
                          {method}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end">
          <Button type="submit" className="w-full md:w-auto bg-primary hover:bg-primary/90">
            <Zap />
            Start Attack
          </Button>
        </div>
      </form>
    </Form>
  );
}
