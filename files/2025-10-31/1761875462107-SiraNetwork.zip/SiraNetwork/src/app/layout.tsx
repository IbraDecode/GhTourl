
"use client";

import * as React from 'react';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { BottomNavbar } from './components/bottom-navbar';
import Image from 'next/image';
import { DynamicIsland } from './components/dynamic-island';
import { DashboardState } from '@/lib/state';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const { servers, setAttacks, setLiveStats } = DashboardState.useState();

  React.useEffect(() => {
    const onlineServers = servers.filter(s => s.status === 'Online');
    
    if (onlineServers.length === 0) {
      // If no servers are online, clear stats and stop polling
      setAttacks(() => []);
      setLiveStats(() => ({ totalRequests: 0, successfulRequests: 0, failedRequests: 0, rps: 0 }));
      return;
    }

    const interval = setInterval(async () => {
      try {
        // Poll each online server for stats
        const allStatsPromises = onlineServers.map(server => {
            const originalUrl = `${server.url}/stats`;
            const proxyUrl = `/api/proxy?url=${encodeURIComponent(originalUrl)}`;
            return fetch(proxyUrl).then(res => {
              if (!res.ok) {
                console.error(`Failed to fetch stats from ${server.url}: ${res.status}`);
                return null; // Return null for failed fetches
              }
              return res.json();
            });
        });
        
        const results = await Promise.all(allStatsPromises);
        
        // Aggregate stats from all servers
        const aggregatedStats = results.reduce((acc, current) => {
          if (!current) return acc; // Skip failed fetches
          acc.attacks = [...(acc.attacks || []), ...(current.attacks || [])];
          acc.liveStats.totalRequests += current.liveStats?.totalRequests || 0;
          acc.liveStats.successfulRequests += current.liveStats?.successfulRequests || 0;
          acc.liveStats.failedRequests += current.liveStats?.failedRequests || 0;
          acc.liveStats.rps += current.liveStats?.rps || 0;
          return acc;
        }, { 
          attacks: [], 
          liveStats: { totalRequests: 0, successfulRequests: 0, failedRequests: 0, rps: 0 } 
        });

        setAttacks(() => aggregatedStats.attacks);
        setLiveStats(() => aggregatedStats.liveStats);

      } catch (error) {
        console.error("Error polling for stats:", error);
        // In case of a network error, reset stats
        setAttacks(() => []);
        setLiveStats(() => ({ totalRequests: 0, successfulRequests: 0, failedRequests: 0, rps: 0 }));
      }
    }, 2000); // Poll every 2 seconds

    return () => clearInterval(interval);
  }, [servers]);


  return (
    <html lang="en" className="dark">
      <head>
        <title>SiraNetwork</title>
        <meta name="description" content="Advanced automation tool" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased">
          <div className="relative flex flex-col min-h-screen">
            <DynamicIsland />
            <div className="absolute bottom-0 left-0 right-0 z-0 h-96 w-full opacity-10">
              <Image
                src="https://raw.githubusercontent.com/IbraDecode/GhTourl/main/files/2025-10-30/1761808764360-sticker.webp"
                alt="Background Wave"
                fill
                className="object-cover"
              />
            </div>
            <main className="flex-1 pb-24 z-10">{children}</main>
            <BottomNavbar />
          </div>
          <Toaster />
      </body>
    </html>
  );
}
