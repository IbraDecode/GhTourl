
"use client";

import * as React from 'react';
import { useState, useEffect } from 'react';
import type { Attack, Server, MusicPlayerState, LiveStats } from "@/lib/types";
import serverData from './servers.json';

// This is a global state management solution to share state between pages.

type DashboardStateData = {
    attacks: Attack[];
    servers: Server[];
    musicPlayer: MusicPlayerState;
    liveStats: LiveStats;
};

// Initialize server state from the imported JSON file.
// The JSON file is expected to contain an array of server objects.
const initialServers: Server[] = serverData.servers.map((server: any, index: number) => ({
  id: server.id || `server-${index}-${Math.random().toString(36).substring(2, 9)}`,
  url: server.url,
  status: server.status || "Untested",
}));

const initialState: DashboardStateData = {
    attacks: [],
    servers: initialServers,
    musicPlayer: {
      isVisible: false,
      isPlaying: false,
      isExpanded: false,
      isMinimized: false, 
      track: null,
    },
    liveStats: {
        totalRequests: 0,
        successfulRequests: 0,
        failedRequests: 0,
        rps: 0,
    }
};

let state: DashboardStateData = { ...initialState };

const listeners = new Set<() => void>();

const subscribe = (listener: () => void) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
};

const setState = (updater: (prevState: DashboardStateData) => DashboardStateData) => {
    state = updater(state);
    listeners.forEach(l => l());
};

const useSharedState = () => {
    const [localState, setLocalState] = useState(state);

    useEffect(() => {
        const unsubscribe = subscribe(() => setLocalState(state));
        return () => unsubscribe();
    }, []);

    const stableSetters = React.useCallback(() => ({
        setAttacks: (updater: (prev: Attack[]) => Attack[]) => {
            setState(prevState => ({ ...prevState, attacks: updater(prevState.attacks) }));
        },
        setServers: (updater: (prev: Server[]) => Server[]) => {
            setState(prevState => ({ ...prevState, servers: updater(prevState.servers) }));
        },
        setMusicPlayer: (updater: (prev: MusicPlayerState) => MusicPlayerState) => {
            setState(prevState => ({ ...prevState, musicPlayer: updater(prevState.musicPlayer) }));
        },
        setLiveStats: (updater: (prev: LiveStats) => LiveStats) => {
            setState(prevState => ({ ...prevState, liveStats: updater(prevState.liveStats) }));
        }
    }), []);

    return { ...localState, ...stableSetters() };
};

export const DashboardState = {
    useState: useSharedState,
};

